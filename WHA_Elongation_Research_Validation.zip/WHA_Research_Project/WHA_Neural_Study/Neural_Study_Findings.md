# Deep neural and strength-guided implementation study

## Actual outcome

A regularized neural/tree hybrid improved the original composition-partition result, but the gain did not reproduce on the shuffled partition. Pure neural selection was weaker than the previous reference. The implementation is complete, but this experiment does not establish a consistent general accuracy improvement. Keep the prior models as comparators rather than promoting the new neural model as a proven replacement.

## Implemented methods

- A two-hidden-layer MLP and three-hidden-layer feed-forward networks with 64, 32 and 16 ReLU units.
- L2 regularization, Adam learning rate 0.003, target standardization and two seeds (42 and 137) averaged at inference.
- Explicit composition-group early stopping. A further 20% group split inside permitted training data chooses epochs. The preprocessor and target scaler initially fit on the stopping-training subset only. The network is then refitted on all permitted training rows for that epoch count. The outer test never chooses epochs.
- Multitask networks use standardized UTS as a second training output, scaled by 0.5 relative to standardized EL (a 0.25 relative squared-loss coefficient). UTS is never an input feature or an inference requirement.
- A 14-descriptor compact composition-processing representation, avoiding the ambiguous HT temperature, plus the existing 30-feature engineered representation as an alternative.
- Kernel ridge regression, target-scaled SVR, regularized histogram boosting, compact Random Forest and Huber boosting.
- Neural/ExtraTrees blends with fixed neural weights 0.25 and 0.5, chosen using inner validation.
- Exploratory follow-up: spline Ridge models and strength-guided regressors. Their UTS feature is built by three-fold composition cross-fitting inside training data; the fitted first-stage UTS model predicts it at inference. Measured test UTS is never used.

Neural code uses scikit-learn MLPRegressor and partial_fit. The selected full-data network has 18 post-imputation inputs, hidden sizes 64-32-16 and one EL output, with 3,841 parameters per seed. Full-data stopping selected 75 and 45 epochs for the two seeds. These stopping curves are internal training diagnostics, not estimates of final generalization.

## Validation

The same 433 eligible records, 183 composition groups, five outer folds and three inner folds were used as in the previous study. A second run shuffles both grouping stages with seed 2026. All imputers, scalers and target scalers fit inside the permitted training scope. Selection maximizes mean inner EL R² only. Phase A has 46 model/ensemble choices, including the previous 24. Phase B adds four learners and one strength blend, giving 51 choices. Phase B was designed after viewing Phase A results and is exploratory on the same data.

| Partition | Procedure | Mean fold R² | Pooled OOF R² | MAE pp | High-EL MAE pp |
|---|---|---:|---:|---:|---:|
| Original | Previous reference | 0.5765 | 0.5812 | 4.208 | 5.256 |
| Original | Inner-selected neural family | 0.5396 | 0.5452 | 4.352 | 5.395 |
| Original | Expanded model selection | 0.5964 | 0.5999 | 4.000 | 4.672 |
| Shuffled 2026 | Previous reference | 0.5176 | 0.5164 | 4.561 | 6.113 |
| Shuffled 2026 | Inner-selected neural family | 0.3911 | 0.3726 | 5.083 | 5.953 |
| Shuffled 2026 | Expanded model selection | 0.5069 | 0.5103 | 4.573 | 6.259 |

On the original partition, mean R² increased from 0.5765 to 0.5964 and MAE fell from 4.208 to 4.000 pp. On the shuffled partition, mean R² fell from 0.5176 to 0.5069 and MAE increased slightly from 4.561 to 4.573 pp. These are different partitions of the same dataset, not independent test collections. R² is not an accuracy percentage.

The paired composition-bootstrap intervals for expanded-minus-previous pooled R² are [-0.0398, 0.0710] and [-0.0323, 0.0154]. Both cross zero. They condition on the fitted OOF predictions and do not include all repeated-search or training uncertainty.

The strength-guided and spline additions did not change the inner-selected outer predictions on either partition. No additional improvement is attributed to those methods. Their candidate scores and implementation are preserved under phase_b/.

## Stricter transfer diagnostics

The full-data selected recipes were frozen and refitted in the same Dataset 2 reported-reference stress setup as before. Each fold also removes training compositions appearing in the held-out fold. These are retrospective fixed-recipe tests with reduced training size and local reference labels, not independent publication-wise confirmation.

| Recipe | Pooled R² | MAE pp |
|---|---:|---:|
| Previous fixed ensemble | 0.1243 | 6.817 |
| Research_Selected_Model | 0.1738 | 6.530 |
| Neural_Model | -0.0657 | 7.557 |

The hybrid improves this diagnostic modestly, but its pooled R² remains weak. The pure neural model does not provide a better transfer result.

The previously extracted three-record paper pilot is also retained. It is purposively selected, comes from an already-seen source paper and contains an unknown HT temperature. Its results must not be called independent validation.

| Model | Pilot MAE pp |
|---|---:|
| Previous ensemble | 5.526 |
| Previous error-focused ExtraTrees | 4.654 |
| Research_Selected_Model | 8.407 |
| Neural_Model | 15.391 |

The new models are worse on this small retrospective pilot. That negative result is included alongside the more favorable original-partition result. No model or weight was changed after seeing the transfer outcomes.

## Saved models and use

Full-data model selection uses three grouped folds, then refits eligible training rows. Its selection scores are not independent performance estimates. The selected experimental hybrid is 25% DNN and 75% ExtraTrees. The pure neural and three-layer exports both contain the selected 64-32-16 two-seed model.

- WHA_Neural_Study/Research_Selected_Model.joblib: selected experimental hybrid.
- WHA_Neural_Study/Neural_Model.joblib: selected neural model.
- WHA_Neural_Study/Three_Layer_DNN.joblib: explicit three-hidden-layer export.
- phase_b/ contains the exploratory follow-up outputs and equivalent final fitted recipes. Fixed-recipe transfer results are reused only after recipe and supplied-data prediction equality checks.

The earlier higher-R² and high-EL-error-focused models remain in the package. The compact Example_Input.csv contains five training records for schema demonstration only; it is not an independent test.

```bash
pip install -r requirements.txt
python run_neural_study.py
python run_neural_study.py --repeat
python fit_neural_models.py
python evaluate_neural_transfer.py
python run_neural_study.py --phase-b
python run_neural_study.py --phase-b --repeat
python fit_neural_models.py --phase-b
python predict_neural.py input.xlsx output.csv
python predict_neural.py input.xlsx dnn_predictions.csv Three_Layer_DNN
```

Run from the extracted project root. The latest notebook is 09_Advanced_Implementation.ipynb. Prediction requires original input columns, with explicit elemental zeros and verified unit conventions. It does not require measured EL or UTS. Invalid composition totals produce a review flag and no prediction. All source-data limitations from the earlier report still apply.

## Verification

Previous reference predictions reproduce exactly. All four nested runs retain one test assignment per composition group, 433 complete OOF predictions per procedure and exactly one selected candidate per inner search. Every neural stopping split has zero group overlap. Model reload predictions match, target columns can be removed or altered without changing inference, and invalid compositions are rejected. Strength features use training-only composition cross-fitting. No synthetic observations, unverified source corrections, favorable split selection or training-score accuracy claims are used.

The main result is a tested implementation and a limited improvement on one partition and one transfer diagnostic, with a failure to reproduce the gain on the shuffled partition. A 0.80 generalization R² or a broad accuracy breakthrough is not supported.

Reference: scikit-learn MLPRegressor documentation, https://scikit-learn.org/stable/modules/generated/sklearn.neural_network.MLPRegressor.html . Installed runtime and package requirements use scikit-learn 1.8.0.
