"""Usage: python predict_elongation.py input.xlsx output.csv"""
from pathlib import Path
import sys,joblib,pandas as pd
from elongation_predictor import predict
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit(__doc__)
    root=Path(__file__).resolve().parent
    bundle=joblib.load(root/'WHA_Improvement/Elongation_Model.joblib')
    source=Path(sys.argv[1]);d=pd.read_excel(source) if source.suffix.lower()=='.xlsx' else pd.read_csv(source)
    out=d.copy();result=predict(bundle,d)
    for c in result:out[c]=result[c]
    out.to_csv(sys.argv[2],index=False)
    print('Saved',len(out),'rows to',sys.argv[2])
