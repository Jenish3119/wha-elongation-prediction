"""Final source audit, frozen-model pilot, reference stress test and interpretation."""
from pathlib import Path
import json,hashlib,joblib
import numpy as np,pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error
from elongation_predictor import COMP,FEATURES,fit_component,component_predict,predict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;O=R/'WHA_Final_Research';O.mkdir(exist_ok=True)
raw=R/'inputs/Master_WHA_Dataset_Cleaned.xlsx';df=pd.read_excel(raw);df.insert(0,'Excel row',np.arange(len(df))+2)
total=df[COMP].sum(axis=1);valid=total.between(98,102);d=df[valid].reset_index(drop=True)
groups=pd.factorize(d[COMP].round(4).apply(tuple,axis=1))[0];y=d['Elongation (%)'].to_numpy(float)
audit=df.copy();audit['Record ID']='master-excelrow'+audit['Excel row'].astype(str);audit['Calculated composition total (%)']=total;audit['Eligible composition']=valid
audit['HT temperature verification']='Unverified unit as supplied';audit['HT missing does not mean untreated']=df[['HT Temp Standardized','HT Time (hr)']].isna().any(axis=1)
for c in ['HT Type','Quenching Medium','Swaging Temperature','Ageing Schedule','Primary Citation DOI']:
    audit['Recovery needed '+c]=True
audit.to_csv(O/'All_Rows_Source_Audit.csv',index=False);audit[valid].to_csv(O/'WHA_Model_Ready_Audited.csv',index=False);audit[~valid].to_csv(O/'Quarantined_Compositions.csv',index=False)
issues=[{'issue':'Composition row 304','status':'Unresolved','evidence':'Parsed W=0, total 20%; original source not available.','action':'Verify original composition; do not infer 80W.'},{'issue':'Composition row 331','status':'Unresolved','evidence':'93W+7Ni+3Fe=103%; original source not available.','action':'Verify original composition; do not renormalize.'},{'issue':'Dataset 1 HT units','status':'Unresolved','evidence':'106 populated values; numerical range suggests a possible unit difference, not proof.','action':'Obtain original unit annotation and citation.'},{'issue':'Original processing categories','status':'Unavailable in accessible original uploads','evidence':'Preparation notebook selects columns that omit HT type, quenching, swaging temperature and ageing conditions.','action':'Recover original wha-1.xlsx and Book 4(Sheet1).csv.'},{'issue':'Complete primary references','status':'Unresolved','evidence':'110 Dataset 1 records lack reference IDs; Dataset 2 has 52 local reference labels.','action':'Map every reference label to a globally unique citation.'},{'issue':'Verified correction intake','status':'No verified edits available','evidence':'Existing correction intake contains pending rows without verified values or evidence.','action':'Accept future edits only with field-level source evidence.'}]
pd.DataFrame(issues).to_csv(O/'Source_Recovery_Status.csv',index=False)
def metrics(t,p):
    h=t>24
    return {'n':len(t),'R2':float(r2_score(t,p)),'MAE_pp':float(mean_absolute_error(t,p)),'RMSE_pp':float(np.sqrt(mean_squared_error(t,p))),'high_EL_n':int(h.sum()),'high_EL_MAE_pp':float(mean_absolute_error(t[h],p[h])) if h.any() else np.nan}
# Freeze file hashes before the retrospective out-of-master pilot. No model is fitted on pilot records.
paths={'higher_R2':R/'WHA_Improvement/Elongation_Model.joblib','error_focused':R/'WHA_Tail_Study/High_Elongation_Model.joblib'}
frozen={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in paths.items()};(O/'Frozen_Model_Hashes.json').write_text(json.dumps(frozen,indent=2))
pilot=[]
for label,w,re,co,stt,htt,el in [('NS1',87.10,3.,.4,1.,4.,27.),('NS2',88.90,1.,.6,1.5,2.,23.),('NS3',88.10,2.,.4,1.,4.,30.)]:
    row={c:0. for c in COMP};row.update({'W (%)':w,'Ni (%)':5.25,'Fe (%)':1.75,'Re (%)':re,'Ta (%)':2.5,'Co (%)':co,'Sintering Temp (°C)':1500.,'Sintering Time (hr)':stt,'Deformation Before HT (%)':0.,'HT Temp Standardized':np.nan,'HT Time (hr)':htt,'Post Deformation (%)':0.,'Sample':label,'Observed EL (%)':el,'Reported EL uncertainty (pp)':1.,'Source DOI':'10.1016/j.matdes.2026.115545','Input evidence':'PDF page 7 Table 2; no deformation supported by page 11 Section 4.2','Target evidence':'PDF page 11 Table 4','Unknown input':'HT temperature not specified in selected source tables'})
    pilot.append(row)
pilot=pd.DataFrame(pilot)
training_compositions=set(d[COMP].round(4).apply(tuple,axis=1));assert not any(k in training_compositions for k in pilot[COMP].round(4).apply(tuple,axis=1))
assert pilot[COMP].sum(axis=1).between(99.999,100.001).all()
pilot_rows=[]
for name,path in paths.items():
    b=joblib.load(path);p=predict(b,pilot).prediction_EL_percent.to_numpy();pilot[name+' prediction (%)']=p;pilot[name+' absolute error (pp)']=abs(pilot['Observed EL (%)']-p);pilot_rows.append({'model':name,**metrics(pilot['Observed EL (%)'].to_numpy(),p)})
pilot.to_csv(O/'Retrospective_Three_Record_Pilot.csv',index=False);pd.DataFrame(pilot_rows).to_csv(O/'Pilot_Metrics.csv',index=False)
# Fixed recipes, not additional tuning: reference-labelled group holdout in Dataset 2, with shared compositions purged from training.
spec_ref=json.loads((R/'WHA_Improvement/experiment_plan.json').read_text())['specs'];tail_plan=json.loads((R/'WHA_Tail_Study/study_plan.json').read_text());specs=tail_plan['specs']
s=d[d['Data Source']=='Dataset 2'].reset_index(drop=True);sy=s['Elongation (%)'].to_numpy(float);refs=s.Reference.astype(str).str.replace('\xa0','',regex=False).str.strip().to_numpy();cg=s[COMP].round(4).apply(tuple,axis=1).to_numpy()
stress={k:np.full(len(s),np.nan) for k in ['higher_R2_recipe','weighted_ExtraTrees','training_mean']};stress_rows=[];membership=np.zeros(len(s),int)
for f,(tr0,te) in enumerate(GroupKFold(5).split(s,sy,refs),1):
    testkeys=set(cg[te]);tr=np.array([i for i in tr0 if cg[i] not in testkeys]);assert set(refs[tr]).isdisjoint(refs[te]);assert set(cg[tr]).isdisjoint(cg[te]);assert len(tr)>30
    print('Reported-reference stress fold',f,'train',len(tr),'test',len(te),'purged',len(tr0)-len(tr),flush=True)
    c1=fit_component(s.iloc[tr],sy[tr],spec_ref['eng_sqrt4']);c2=fit_component(s.iloc[tr],sy[tr],spec_ref['eng_extra']);c3=fit_component(s.iloc[tr],sy[tr],specs['eng_extra_high3'])
    pp={'higher_R2_recipe':.25*component_predict(c1,s.iloc[te])+.75*component_predict(c2,s.iloc[te]),'weighted_ExtraTrees':component_predict(c3,s.iloc[te]),'training_mean':np.repeat(sy[tr].mean(),len(te))}
    membership[te]=f
    for k,p in pp.items():stress[k][te]=p;stress_rows.append({'fold':f,'model':k,'train_n':len(tr),'test_n':len(te),'purged_training_rows':len(tr0)-len(tr),'train_reported_refs':len(set(refs[tr])),'test_reported_refs':len(set(refs[te])),**metrics(sy[te],p)})
pd.DataFrame(stress_rows).to_csv(O/'Purged_Reference_Fold_Metrics.csv',index=False)
pd.DataFrame([{'model':k,**metrics(sy,p)} for k,p in stress.items()]).to_csv(O/'Purged_Reference_Pooled_Metrics.csv',index=False)
sp=s[['Excel row','Reference','Original Composition','Elongation (%)']].copy();sp['fold']=membership
for k,p in stress.items():sp[k+' prediction']=p
sp.to_csv(O/'Purged_Reference_Predictions.csv',index=False)
# Held-out joint block permutation for the balanced selection procedure. Derived features regenerate from permuted raw inputs.
blocks={'Composition':COMP,'Sintering':['Sintering Temp (°C)','Sintering Time (hr)'],'Heat treatment':['HT Temp Standardized','HT Time (hr)'],'Deformation':['Deformation Before HT (%)','Post Deformation (%)']}
importance=[]
for repeat in [False,True]:
    q=R/'WHA_Tail_Study';cv=GroupKFold(5)
    if repeat:q=q/'robustness';cv=GroupKFold(5,shuffle=True,random_state=2026)
    foldtable=pd.read_csv(q/'outer_fold_metrics.csv');expected=pd.read_csv(q/'OOF_predictions.csv')
    for f,(tr,te) in enumerate(cv.split(d,y,groups),1):
        winner=foldtable[(foldtable.outer_fold==f)&(foldtable.procedure=='balanced_focus')].candidate.item();ws=tail_plan['blends'].get(winner,{winner:1.})
        models={k:fit_component(d.iloc[tr],y[tr],specs[k]) for k in ws}
        def pr(frame):return sum(w*component_predict(models[k],frame) for k,w in ws.items())
        test=d.iloc[te].copy();base=pr(test);assert np.allclose(base,expected.iloc[te].balanced_focus_prediction,atol=1e-9)
        base_r2=r2_score(y[te],base);base_mae=mean_absolute_error(y[te],base)
        for j,(block,columns) in enumerate(blocks.items()):
            for k in range(10):
                rng=np.random.default_rng(2026+int(repeat)*10000+f*100+j*10+k);shuffled=test.copy();order=rng.permutation(len(test));shuffled.loc[:,columns]=test[columns].to_numpy()[order];p=pr(shuffled)
                importance.append({'partition':'shuffled' if repeat else 'original','fold':f,'block':block,'permutation':k,'R2_drop':base_r2-r2_score(y[te],p),'MAE_increase_pp':mean_absolute_error(y[te],p)-base_mae})
        print('Held-out interpretation',repeat,f,flush=True)
ip=pd.DataFrame(importance);ip.to_csv(O/'Heldout_Block_Permutation_Raw.csv',index=False)
fimp=ip.groupby(['partition','fold','block'],as_index=False)[['R2_drop','MAE_increase_pp']].mean();fimp.to_csv(O/'Heldout_Block_Permutation_By_Fold.csv',index=False)
summary=fimp.groupby('block').agg(mean_R2_drop=('R2_drop','mean'),fold_SD_R2_drop=('R2_drop','std'),mean_MAE_increase_pp=('MAE_increase_pp','mean'),positive_fold_count=('R2_drop',lambda x:int((x>0).sum()))).sort_values('mean_R2_drop',ascending=False);summary.to_csv(O/'Heldout_Block_Importance.csv')
fig,ax=plt.subplots(figsize=(7.5,4));z=summary.iloc[::-1];ax.barh(z.index,z.mean_R2_drop,xerr=z.fold_SD_R2_drop,color='#247e83',capsize=3);ax.axvline(0,color='grey',lw=.8);ax.set(xlabel='Mean held-out R² decrease after joint permutation',title='Predictive reliance on input blocks');fig.tight_layout();fig.savefig(O/'Heldout_Block_Importance.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(7.5,4));xx=np.arange(3);ax.errorbar(xx,pilot['Observed EL (%)'],yerr=pilot['Reported EL uncertainty (pp)'],fmt='o',color='black',label='Published measurements (reported ±1 pp)')
for k,off in [('higher_R2',-.08),('error_focused',.08)]:ax.scatter(xx+off,pilot[k+' prediction (%)'],label=k.replace('_',' '),s=45)
ax.set_xticks(xx,pilot.Sample);ax.set(ylabel='Elongation (%)',title='Retrospective pilot outside the master workbook');ax.legend(fontsize=8);fig.tight_layout();fig.savefig(O/'Pilot_Predictions.png',dpi=180);plt.close(fig)
status={'verified_source_corrections_applied':0,'original_master_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'original_rows':len(df),'eligible_rows':len(d),'reported_reference_subset_rows':len(s),'reported_reference_labels':len(set(refs)),'true_independent_external_validation':'Not completed; no verified independently sourced complete test set. Pilot comes from the already-seen paper and has an unknown HT temperature.','model_development_status':'Research workflow and retrospective evaluations complete; source-data repair and independent external validation remain open.'}
(O/'Final_Status.json').write_text(json.dumps(status,indent=2))
print('Pilot',pd.DataFrame(pilot_rows).to_string(index=False),flush=True);print('Reference stress',pd.DataFrame([{'model':k,**metrics(sy,p)} for k,p in stress.items()]).to_string(index=False),flush=True);print(summary.to_string(),flush=True)
