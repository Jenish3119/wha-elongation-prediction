"""Feature generation, training and inference for the WHA validation model."""
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from catboost import CatBoostRegressor
COMP=[f'{e} (%)' for e in ['W','Ni','Fe','Co','Mo','Re','Cu','Mn','Cr','Ta','Hf','La']]
FEATURES=COMP+['Sintering Temp (°C)','Sintering Time (hr)','Deformation Before HT (%)','HT Temp Standardized','HT Time (hr)','Post Deformation (%)']
def engineered(d):
    e=d[FEATURES].copy()
    e['non_W_total']=d[COMP].sum(axis=1)-d['W (%)']
    e['Ni_Fe_Co_total']=d[['Ni (%)','Fe (%)','Co (%)']].sum(axis=1)
    e['Ni_Fe_ratio']=d['Ni (%)']/d['Fe (%)'].replace(0,np.nan)
    e['Fe_absent']=(d['Fe (%)']==0).astype(int)
    e['Ni_fraction_NiFeCo']=d['Ni (%)']/e['Ni_Fe_Co_total'].replace(0,np.nan)
    e['Co_fraction_NiFeCo']=d['Co (%)']/e['Ni_Fe_Co_total'].replace(0,np.nan)
    e['Mo_Re_Ta_total']=d[['Mo (%)','Re (%)','Ta (%)']].sum(axis=1)
    pre=d['Deformation Before HT (%)'];post=d['Post Deformation (%)']
    e['sequential_reduction_proxy']=100*(1-(1-pre/100)*(1-post/100))
    e['pre_post_interaction']=pre*post/100
    e['reduction_binder_interaction']=e['sequential_reduction_proxy']*e['Ni_Fe_Co_total']/100
    e['log_sintering_time']=np.log1p(d['Sintering Time (hr)'])
    e['log_HT_time']=np.log1p(d['HT Time (hr)'])
    return e
def matrix(d,variant):
    e=d[FEATURES] if variant=='base' else engineered(d)
    if variant=='no_HT_temperature':e=e.drop(columns='HT Temp Standardized')
    return e.to_numpy(float)
def fit_component(d,y,spec):
    a=matrix(d,spec['variant']);imp=None;scale=None
    if not spec.get('native',False):imp=SimpleImputer(strategy='median',add_indicator=True);a=imp.fit_transform(a)
    target=np.sqrt(y) if spec.get('target')=='sqrt' else y
    if spec['kind']=='cat':m=CatBoostRegressor(iterations=spec['it'],depth=spec['depth'],learning_rate=spec['lr'],l2_leaf_reg=spec['l2'],random_seed=42,verbose=False,thread_count=2,allow_writing_files=False)
    elif spec['kind'] in ['extra','rf']:
        cls=ExtraTreesRegressor if spec['kind']=='extra' else RandomForestRegressor
        m=cls(n_estimators=spec['trees'],min_samples_leaf=spec['leaf'],random_state=42,n_jobs=2)
    else:scale=StandardScaler();a=scale.fit_transform(a);m=SVR(C=spec['C'],gamma=spec['gamma'],epsilon=.5)
    kw={}
    if spec.get('weighted') or spec.get('high_weight') or spec.get('group_balance'):
        factor=spec.get('high_weight',2. if spec.get('weighted') else 1.)
        weights=np.where(y>24,factor,1.)
        if spec.get('group_balance'):
            groups=pd.factorize(d[COMP].round(4).apply(tuple,axis=1))[0]
            counts=np.bincount(groups)
            weights=weights/counts[groups]
            weights=weights/weights.mean()
        kw={'sample_weight':weights}
    m.fit(a,target,**kw)
    return {'spec':spec,'imputer':imp,'scaler':scale,'model':m}
def component_predict(component,d):
    x=matrix(d,component['spec']['variant'])
    if component['imputer'] is not None:x=component['imputer'].transform(x)
    if component['scaler'] is not None:x=component['scaler'].transform(x)
    p=component['model'].predict(x)
    return np.maximum(p,0)**2 if component['spec'].get('target')=='sqrt' else p
def predict(bundle,d):
    absent=[c for c in FEATURES if c not in d]
    if absent:raise ValueError('Required columns missing: '+', '.join(absent))
    if d[COMP].isna().any().any():raise ValueError('Element percentages must be explicit; do not infer absent elements from blanks.')
    valid=d[COMP].sum(axis=1).between(98,102)&(d[COMP]>=0).all(axis=1)
    out=pd.DataFrame({'prediction_EL_percent':np.nan,'composition_total_percent':d[COMP].sum(axis=1),'input_status':np.where(valid,'composition check passed','composition needs review')},index=d.index)
    if valid.any():out.loc[valid,'prediction_EL_percent']=sum(w*component_predict(bundle['components'][k],d.loc[valid]) for k,w in bundle['weights'].items())
    return out
