"""Usage: python predict_neural.py input.xlsx output.csv [Research_Selected_Model|Neural_Model|Three_Layer_DNN] [--phase-b]"""
from pathlib import Path
import sys,joblib,pandas as pd
from advanced_models import predict_saved_model
if __name__=='__main__':
    phase_b='--phase-b' in sys.argv
    if phase_b:sys.argv.remove('--phase-b')
    if len(sys.argv) not in [3,4]:raise SystemExit(__doc__)
    label=sys.argv[3] if len(sys.argv)==4 else 'Research_Selected_Model'
    if label not in ['Research_Selected_Model','Neural_Model','Three_Layer_DNN']:raise SystemExit('Unknown model choice')
    r=Path(__file__).resolve().parent;p=Path(sys.argv[1]);d=pd.read_excel(p) if p.suffix.lower()=='.xlsx' else pd.read_csv(p)
    folder=r/'WHA_Neural_Study'
    if phase_b:folder=folder/'phase_b'
    bundle=joblib.load(folder/(label+'.joblib'));out=d.copy();prediction=predict_saved_model(bundle,d)
    for c in prediction:out[c]=prediction[c]
    out.to_csv(sys.argv[2],index=False)
