"""Regularized neural, multitask and compact-feature regression models."""
import warnings
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import SplineTransformer
from sklearn.feature_selection import VarianceThreshold
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import GroupShuffleSplit
from sklearn.model_selection import GroupKFold
from sklearn.neural_network import MLPRegressor
from sklearn.kernel_ridge import KernelRidge
from sklearn.svm import SVR
from sklearn.ensemble import HistGradientBoostingRegressor,RandomForestRegressor,GradientBoostingRegressor
from sklearn.ensemble import ExtraTreesRegressor
from catboost import CatBoostRegressor
from threadpoolctl import threadpool_limits
from elongation_predictor import COMP,FEATURES,engineered,component_predict

NEW_SPECS={
 'mlp_small':{'kind':'neural','variant':'compact','layers':[32,16],'alpha':1.,'multitask':False},
 'dnn_three_layer':{'kind':'neural','variant':'compact','layers':[64,32,16],'alpha':1.,'multitask':False},
 'dnn_strong_reg':{'kind':'neural','variant':'engineered','layers':[64,32,16],'alpha':10.,'multitask':False},
 'multitask_dnn':{'kind':'neural','variant':'compact','layers':[64,32,16],'alpha':1.,'multitask':True},
 'multitask_strong_reg':{'kind':'neural','variant':'compact','layers':[64,32,16],'alpha':10.,'multitask':True},
 'kernel_ridge_smooth':{'kind':'kernel','variant':'compact','alpha':1.,'gamma':.01},
 'kernel_ridge_flexible':{'kind':'kernel','variant':'compact','alpha':.1,'gamma':.03},
 'svr_scaled':{'kind':'svr','variant':'compact','C':5.,'gamma':.03},
 'hist_boost_shallow':{'kind':'hist','variant':'compact','leaves':7,'min_leaf':10,'l2':10.},
 'hist_boost_regularized':{'kind':'hist','variant':'engineered','leaves':15,'min_leaf':20,'l2':10.},
 'compact_random_forest':{'kind':'forest','variant':'compact'},
 'huber_boost':{'kind':'huber','variant':'compact'},
}
PHASE_B_SPECS={
 'strength_guided_extra':{'kind':'strength','variant':'compact','second_stage':'extra'},
 'strength_guided_cat':{'kind':'strength','variant':'compact','second_stage':'cat'},
 'spline_ridge':{'kind':'spline','variant':'compact','alpha':1.},
 'spline_ridge_regularized':{'kind':'spline','variant':'compact','alpha':10.},
}
NN_SEEDS=[42,137]
NN_MAX_EPOCHS=240
NN_LEARNING_RATE=.003
NN_PATIENCE=30
NN_AUXILIARY_SCALE=.5

def feature_frame(d,variant):
    if variant=='base':return d[FEATURES].copy()
    if variant=='engineered':return engineered(d)
    x=d[['Co (%)','Re (%)','Mo (%)','Cr (%)','Cu (%)','Ta (%)','Sintering Temp (°C)','Sintering Time (hr)','Deformation Before HT (%)','Post Deformation (%)','HT Time (hr)']].copy()
    x['Ni_Fe_total']=d['Ni (%)']+d['Fe (%)']
    x['Ni_Fe_ratio']=d['Ni (%)']/d['Fe (%)'].replace(0,np.nan)
    x['Fe_absent']=(d['Fe (%)']==0).astype(float)
    return x

def preprocessor():
    return make_pipeline(SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),StandardScaler())

def nn_model(spec,seed,n):
    return MLPRegressor(hidden_layer_sizes=tuple(spec['layers']),activation='relu',solver='adam',alpha=spec['alpha'],batch_size=min(64,n),learning_rate_init=NN_LEARNING_RATE,shuffle=True,random_state=seed,early_stopping=False)

def fit_method(spec,d,y,aux,groups):
    """No test labels enter this function. Neural stopping uses a further group split."""
    x=feature_frame(d,spec['variant']).to_numpy(float)
    if spec['kind']=='strength':
        bx=d[FEATURES].to_numpy(float);cross=np.full(len(d),np.nan)
        def first():return make_pipeline(SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True),ExtraTreesRegressor(n_estimators=300,min_samples_leaf=2,random_state=42,n_jobs=2))
        for a,b in GroupKFold(3).split(bx,aux,groups):
            assert set(groups[a]).isdisjoint(groups[b]);m=first();m.fit(bx[a],aux[a]);cross[b]=m.predict(bx[b])
        assert np.isfinite(cross).all();strength=first();strength.fit(bx,aux)
        pp=preprocessor();xx=pp.fit_transform(np.column_stack([x,cross]));ys=StandardScaler();yy=ys.fit_transform(np.asarray(y).reshape(-1,1))[:,0]
        model=ExtraTreesRegressor(n_estimators=500,min_samples_leaf=2,random_state=42,n_jobs=2) if spec['second_stage']=='extra' else CatBoostRegressor(iterations=800,depth=4,learning_rate=.03,l2_leaf_reg=10,random_seed=42,verbose=False,thread_count=2,allow_writing_files=False)
        model.fit(xx,yy)
        return {'spec':spec,'preprocessor':pp,'target_scaler':ys,'model':model,'strength_model':strength,'metadata':{'UTS_feature':'Three-fold composition-cross-fitted predictions during fitting; never measured UTS at inference.','training_groups':len(set(groups)),'all_cross_fit_groups_disjoint':True}}
    if spec['kind']=='neural':
        members=[];metadata=[]
        for seed in NN_SEEDS:
            a,b=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=seed).split(x,y,groups))
            assert set(groups[a]).isdisjoint(groups[b])
            rawtarget=np.column_stack([y,aux]) if spec['multitask'] else np.asarray(y).reshape(-1,1)
            pp=preprocessor();xa=pp.fit_transform(x[a]);xb=pp.transform(x[b]);ys=StandardScaler();ya=ys.fit_transform(rawtarget[a]);yb=ys.transform(rawtarget[b])
            if spec['multitask']:ya[:,1]*=NN_AUXILIARY_SCALE
            else:ya=ya[:,0]
            model=nn_model(spec,seed,len(a));best=np.inf;best_epoch=20;last_improvement=0;history=[]
            with threadpool_limits(limits=1):
                for epoch in range(1,NN_MAX_EPOCHS+1):
                    model.partial_fit(xa,ya)
                    if epoch%5==0 and epoch>=20:
                        pr=model.predict(xb);pr=pr[:,0] if spec['multitask'] else pr
                        mse=float(np.mean((pr-yb[:,0])**2));history.append({'epoch':epoch,'training_objective':float(model.loss_),'group_validation_EL_MSE_scaled':mse})
                        if mse<best-.0005:best=mse;best_epoch=epoch;last_improvement=epoch
                        if epoch-last_improvement>=NN_PATIENCE:break
            # Refit on the full permitted training set using the internally selected epoch count.
            final_pp=preprocessor();xx=final_pp.fit_transform(x);final_ys=StandardScaler();yy=final_ys.fit_transform(rawtarget)
            if spec['multitask']:yy[:,1]*=NN_AUXILIARY_SCALE
            else:yy=yy[:,0]
            final=nn_model(spec,seed,len(y))
            with threadpool_limits(limits=1):
                for _ in range(best_epoch):final.partial_fit(xx,yy)
            members.append({'preprocessor':final_pp,'target_scaler':final_ys,'model':final})
            metadata.append({'seed':seed,'best_epoch':best_epoch,'stopping_fit_rows':len(a),'stopping_validation_rows':len(b),'stopping_fit_groups':len(set(groups[a])),'stopping_validation_groups':len(set(groups[b])),'group_overlap_count':0,'history':history})
        return {'spec':spec,'members':members,'metadata':metadata}
    pp=preprocessor();xx=pp.fit_transform(x);ys=StandardScaler();yy=ys.fit_transform(np.asarray(y).reshape(-1,1))[:,0]
    if spec['kind']=='spline':m=make_pipeline(VarianceThreshold(1e-12),SplineTransformer(n_knots=4,degree=3,include_bias=False,extrapolation='linear'),Ridge(alpha=spec['alpha']))
    elif spec['kind']=='kernel':m=KernelRidge(kernel='rbf',alpha=spec['alpha'],gamma=spec['gamma'])
    elif spec['kind']=='svr':m=SVR(C=spec['C'],gamma=spec['gamma'],epsilon=.05)
    elif spec['kind']=='hist':m=HistGradientBoostingRegressor(max_iter=250,learning_rate=.05,max_leaf_nodes=spec['leaves'],min_samples_leaf=spec['min_leaf'],l2_regularization=spec['l2'],early_stopping=False,random_state=42)
    elif spec['kind']=='forest':m=RandomForestRegressor(n_estimators=500,min_samples_leaf=3,max_features=.7,random_state=42,n_jobs=2)
    else:m=GradientBoostingRegressor(loss='huber',n_estimators=300,learning_rate=.05,max_depth=2,min_samples_leaf=5,subsample=.8,random_state=42)
    with threadpool_limits(limits=1):m.fit(xx,yy)
    return {'spec':spec,'preprocessor':pp,'target_scaler':ys,'model':m,'metadata':{}}

def predict_method(bundle,d):
    x=feature_frame(d,bundle['spec']['variant']).to_numpy(float)
    if bundle['spec']['kind']=='strength':x=np.column_stack([x,bundle['strength_model'].predict(d[FEATURES].to_numpy(float))])
    if bundle['spec']['kind']=='neural':
        predictions=[]
        for m in bundle['members']:
            with threadpool_limits(limits=1):p=m['model'].predict(m['preprocessor'].transform(x))
            if bundle['spec']['multitask']:p=p[:,0]
            p=p*m['target_scaler'].scale_[0]+m['target_scaler'].mean_[0];predictions.append(p)
        return np.maximum(np.mean(predictions,axis=0),0.)
    with threadpool_limits(limits=1):p=bundle['model'].predict(bundle['preprocessor'].transform(x))
    return np.maximum(bundle['target_scaler'].inverse_transform(np.asarray(p).reshape(-1,1))[:,0],0.)

def predict_saved_model(bundle,d):
    absent=[c for c in FEATURES if c not in d]
    if absent:raise ValueError('Required input columns missing: '+', '.join(absent))
    if d[COMP].isna().any().any():raise ValueError('Element percentages must be explicit.')
    valid=d[COMP].sum(axis=1).between(98,102)&(d[COMP]>=0).all(axis=1)
    result=pd.DataFrame({'predicted_EL_percent':np.nan,'input_status':np.where(valid,'composition check passed','composition needs review')},index=d.index)
    if valid.any():
        z=d.loc[valid];p=np.zeros(len(z))
        for k,w in bundle['weights'].items():
            c=bundle['components'][k]
            p+=w*(predict_method(c['bundle'],z) if c['family']=='new' else component_predict(c['bundle'],z))
        result.loc[valid,'predicted_EL_percent']=p
    return result
