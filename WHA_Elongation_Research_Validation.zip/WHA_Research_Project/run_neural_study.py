from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error
from advanced_models import NEW_SPECS,PHASE_B_SPECS,fit_method,predict_method,NN_SEEDS,NN_MAX_EPOCHS,NN_AUXILIARY_SCALE
from elongation_predictor import COMP,fit_component,component_predict

R=Path(__file__).resolve().parent;REPEAT='--repeat' in sys.argv;O=R/'WHA_Neural_Study';P=R/'WHA_Improvement'
PHASE_B='--phase-b' in sys.argv
if PHASE_B:O=O/'phase_b'
if REPEAT:O=O/'robustness';P=P/'robustness'
O.mkdir(parents=True,exist_ok=True);CACHE=O/'cache';CACHE.mkdir(exist_ok=True)
prior=json.loads((P/'experiment_plan.json').read_text());old_specs=prior['specs'];blends=prior['blends'].copy();old_candidates=list(old_specs)+list(blends)
phase_a_new_names=list(NEW_SPECS)
if PHASE_B:
    NEW_SPECS={**NEW_SPECS,**PHASE_B_SPECS}
    blends['strength_blend']={'strength_guided_extra':.5,'strength_guided_cat':.5}
for k,s in NEW_SPECS.items():
    if s['kind']=='neural':
        for w in [.25,.5]:blends[f'{k}_extra_blend_{w}']={k:w,'eng_extra':1-w}
rawpath=R/'inputs/Master_WHA_Dataset_Cleaned.xlsx';raw=pd.read_excel(rawpath);raw.insert(0,'Excel row',np.arange(len(raw))+2)
d=raw[raw[COMP].sum(axis=1).between(98,102)].reset_index(drop=True);groups=pd.factorize(d[COMP].round(4).apply(tuple,axis=1))[0];y=d['Elongation (%)'].to_numpy(float);aux=d['UTS (MPa)'].to_numpy(float)
assert np.isfinite(aux).all()
plan={'protocol':'Same 5 outer and 3 inner composition GroupKFold partitions as previous study; shuffled repeat seed 2026. Candidate selection by mean inner EL R2 only.','is_shuffled_repeat':REPEAT,'new_specs':NEW_SPECS,'old_specs':old_specs,'blends':blends,'neural_seeds':NN_SEEDS,'max_epochs':NN_MAX_EPOCHS,'stopping':'A further 20% GroupShuffleSplit of permitted training compositions chooses epochs; then refit all permitted training rows. No row-random early stopping.','auxiliary_UTS_output_scale':NN_AUXILIARY_SCALE,'auxiliary_note':'UTS is a training target only, never an input or inference requirement.','data_sha256':hashlib.sha256(rawpath.read_bytes()).hexdigest(),'data_rows':len(d),'groups':len(set(groups)),'source_limitations':'No source correction, new observations, or verified unit conversions.'}
plan['phase']='B exploratory follow-up, devised after viewing phase A; same reused dataset, no independent confirmatory claim.' if PHASE_B else 'A'
assert plan['data_sha256']==prior['data_sha256'];(O/'Frozen_Experiment_Plan.json').write_text(json.dumps(plan,indent=2))
fp=hashlib.sha256(json.dumps(plan,sort_keys=True).encode()+Path(__file__).read_bytes()+(R/'advanced_models.py').read_bytes()).hexdigest()[:16]
def pred(name,tr,te,tag):
    if name in old_specs:
        old=P/'cache'/f'{tag}_{name}.npy'
        if old.exists():p=np.load(old);assert p.shape==(len(te),);return p
    if PHASE_B and name in phase_a_new_names:
        olddir=R/'WHA_Neural_Study'
        if REPEAT:olddir=olddir/'robustness'
        matches=list((olddir/'cache').glob(f'*_{tag}_{name}.npy'))
        if len(matches)==1:return np.load(matches[0])
    key=hashlib.sha256(np.asarray(tr).tobytes()+np.asarray(te).tobytes()).hexdigest()[:12];path=CACHE/f'{fp}_{key}_{tag}_{name}.npy'
    if path.exists():return np.load(path)
    if name in old_specs:c=fit_component(d.iloc[tr],y[tr],old_specs[name]);p=component_predict(c,d.iloc[te])
    else:
        c=fit_method(NEW_SPECS[name],d.iloc[tr],y[tr],aux[tr],groups[tr]);p=predict_method(c,d.iloc[te]);(CACHE/f'{fp}_{key}_{tag}_{name}.json').write_text(json.dumps(c['metadata']))
    assert np.isfinite(p).all();np.save(path,p);return p
def candidates(p):
    z=dict(p)
    for k,ws in blends.items():z[k]=sum(w*p[n] for n,w in ws.items())
    return z
def metric(t,p):
    h=t>24
    return {'R2':float(r2_score(t,p)),'MAE_pp':float(mean_absolute_error(t,p)),'RMSE_pp':float(np.sqrt(mean_squared_error(t,p))),'high_EL_MAE_pp':float(mean_absolute_error(t[h],p[h])) if h.any() else np.nan}
outer=GroupKFold(5,shuffle=True,random_state=2026) if REPEAT else GroupKFold(5)
oo={k:np.full(len(d),np.nan) for k in ['previous_reference','neural_only_selection','expanded_selection']};fid=np.zeros(len(d),int);foldrows=[];scoresout=[]
neural_names=[k for k,s in NEW_SPECS.items() if s['kind']=='neural']
for f,(tr,te) in enumerate(outer.split(d,y,groups),1):
    print('Outer fold',f,flush=True);assert set(groups[tr]).isdisjoint(groups[te])
    inner=GroupKFold(3,shuffle=True,random_state=2026) if REPEAT else GroupKFold(3);ip={k:np.full(len(tr),np.nan) for k in list(old_specs)+list(NEW_SPECS)};valid=[]
    for j,(a,b) in enumerate(inner.split(tr,y[tr],groups[tr]),1):
        assert set(groups[tr[a]]).isdisjoint(groups[tr[b]])
        for k in ip:ip[k][b]=pred(k,tr[a],tr[b],f'outer{f}_inner{j}')
        valid.append(b);print('  completed inner',j,flush=True)
    cp=candidates(ip);scores={k:float(np.mean([r2_score(y[tr][b],p[b]) for b in valid])) for k,p in cp.items()}
    ref=max(old_candidates,key=lambda k:scores[k]);nn=max(neural_names,key=lambda k:scores[k]);win=max(scores,key=scores.get)
    scoresout.extend({'outer_fold':f,'candidate':k,'mean_inner_R2':v,'chosen_reference':k==ref,'chosen_neural':k==nn,'chosen_expanded':k==win} for k,v in scores.items())
    needed=set()
    for k in [ref,nn,win]:needed.update(blends[k] if k in blends else [k])
    op={k:pred(k,tr,te,f'outer{f}_test') for k in needed}
    for k in [ref,nn,win]:
        if k in blends:op[k]=sum(w*op[n] for n,w in blends[k].items())
    fid[te]=f
    for label,k in [('previous_reference',ref),('neural_only_selection',nn),('expanded_selection',win)]:oo[label][te]=op[k];foldrows.append({'outer_fold':f,'procedure':label,'candidate':k,'test_n':len(te),**metric(y[te],op[k])})
    print('Selected:',ref,nn,win,'R2:',r2_score(y[te],op[win]),flush=True)
fm=pd.DataFrame(foldrows);fm.to_csv(O/'Outer_Fold_Metrics.csv',index=False);pd.DataFrame(scoresout).to_csv(O/'Inner_Candidate_Selection.csv',index=False)
summary=pd.DataFrame([{'procedure':k,**metric(y,p),'mean_fold_R2':fm.loc[fm.procedure==k,'R2'].mean(),'fold_SD_R2':fm.loc[fm.procedure==k,'R2'].std()} for k,p in oo.items()]);summary.to_csv(O/'Comparison.csv',index=False)
previous=pd.read_csv(P/'OOF_predictions.csv');assert np.array_equal(previous['Excel row'],d['Excel row']);assert np.array_equal(previous.outer_fold,fid);assert np.allclose(previous.expanded_selection_prediction,oo['previous_reference'],atol=1e-9)
out=d[['Excel row','Data Source','Original Composition','Reference','Elongation (%)']].copy();out['composition_group']=groups;out['outer_fold']=fid
for k,p in oo.items():out[k+'_prediction']=p;out[k+'_absolute_error']=abs(y-p)
out.to_csv(O/'OOF_Predictions.csv',index=False)
rng=np.random.default_rng(42);ug=np.unique(groups);boot=[]
for _ in range(2000):
    ix=np.concatenate([np.flatnonzero(groups==g) for g in rng.choice(ug,len(ug),replace=True)]);boot.append(r2_score(y[ix],oo['expanded_selection'][ix])-r2_score(y[ix],oo['previous_reference'][ix]))
(O/'Uncertainty.json').write_text(json.dumps({'pooled_R2_difference_95pct_group_bootstrap_interval':np.quantile(boot,[.025,.975]).tolist(),'note':'Conditional OOF bootstrap on repeatedly explored data; not an independent test.'},indent=2))
print(summary.to_string(index=False),flush=True)
