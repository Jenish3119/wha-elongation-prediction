# WHA advanced implementation package

Latest work: WHA_Neural_Study/Neural_Study_Findings.md and 09_Advanced_Implementation.ipynb.

Implemented deep feed-forward networks, grouped early stopping, two-seed ensembling, multitask learning with UTS as a training-only auxiliary target, compact-feature kernel and boosting models, neural/tree hybrids, spline models and composition-cross-fitted UTS-guided regressors.

Actual result: original-partition mean R² improved 0.5765 -> 0.5964 and MAE 4.208 -> 4.000 pp, but shuffled-partition mean R² declined 0.5176 -> 0.5069. The gain is not consistent. The source stress diagnostic improves modestly; the three-record retrospective pilot worsens. Pure neural selection is weaker than the previous reference.

Trained experimental hybrid and three-layer network are included under WHA_Neural_Study/. Previous models, source audit, report and notebooks 05-08 are preserved. Original source gaps and independent external validation remain unresolved.

To use a saved model, install requirements.txt and run python predict_neural.py input.xlsx output.csv. Add Three_Layer_DNN as a final argument to use the explicit 64-32-16 network. No measured UTS or EL is required. Read the findings file for full reproduction and limitations.
