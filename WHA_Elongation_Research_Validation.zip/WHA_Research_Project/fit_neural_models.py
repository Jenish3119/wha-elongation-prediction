from pathlib import Path
import json,hashlib,joblib,sys
import numpy as np,pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score
from advanced_models import NEW_SPECS,PHASE_B_SPECS,fit_method,predict_method,predict_saved_model
from elongation_predictor import COMP,FEATURES,fit_component,component_predict
R=Path(__file__).resolve().parent;O=R/'WHA_Neural_Study';PHASE_B='--phase-b' in sys.argv
phase_a_new_names=list(NEW_SPECS)
if PHASE_B:O=O/'phase_b';NEW_SPECS={**NEW_SPECS,**PHASE_B_SPECS}
C=O/'final_cache';C.mkdir(parents=True,exist_ok=True)
plan=json.loads((O/'Frozen_Experiment_Plan.json').read_text());old=plan['old_specs'];blends=plan['blends'];d=pd.read_excel(R/'inputs/Master_WHA_Dataset_Cleaned.xlsx');d=d[d[COMP].sum(axis=1).between(98,102)].reset_index(drop=True);y=d['Elongation (%)'].to_numpy(float);aux=d['UTS (MPa)'].to_numpy(float);groups=pd.factorize(d[COMP].round(4).apply(tuple,axis=1))[0]
allnames=list(old)+list(NEW_SPECS);ip={k:np.full(len(d),np.nan) for k in allnames};valid=[]
for f,(tr,te) in enumerate(GroupKFold(3).split(d,y,groups),1):
    print('Final-fit selection fold',f,flush=True);assert set(groups[tr]).isdisjoint(groups[te])
    for name in allnames:
        cache=C/f'fold{f}_{name}.npy'
        oldcache=R/'WHA_Neural_Study/final_cache'/f'fold{f}_{name}.npy'
        if PHASE_B and name in list(old)+phase_a_new_names and oldcache.exists():p=np.load(oldcache)
        elif cache.exists():p=np.load(cache)
        elif name in old:c=fit_component(d.iloc[tr],y[tr],old[name]);p=component_predict(c,d.iloc[te]);np.save(cache,p)
        else:c=fit_method(NEW_SPECS[name],d.iloc[tr],y[tr],aux[tr],groups[tr]);p=predict_method(c,d.iloc[te]);np.save(cache,p)
        ip[name][te]=p
    valid.append(te)
for k,ws in blends.items():ip[k]=sum(w*ip[n] for n,w in ws.items())
scores={k:float(np.mean([r2_score(y[ix],p[ix]) for ix in valid])) for k,p in ip.items()}
nn=[k for k,s in NEW_SPECS.items() if s['kind']=='neural'];deep=[k for k in nn if len(NEW_SPECS[k]['layers'])==3]
choices={'Research_Selected_Model':max(scores,key=scores.get),'Neural_Model':max(nn,key=lambda k:scores[k]),'Three_Layer_DNN':max(deep,key=lambda k:scores[k])}
pd.DataFrame([{'candidate':k,'mean_selection_R2':v,'chosen_overall':k==choices['Research_Selected_Model'],'chosen_neural':k==choices['Neural_Model'],'chosen_three_layer':k==choices['Three_Layer_DNN']} for k,v in scores.items()]).to_csv(O/'Final_Fit_Selection.csv',index=False)
trained={};meta={}
for label,name in choices.items():
    ws=blends.get(name,{name:1.})
    for k in ws:
        if k not in trained:
            trained[k]={'family':'legacy','bundle':fit_component(d,y,old[k])} if k in old else {'family':'new','bundle':fit_method(NEW_SPECS[k],d,y,aux,groups)}
    bundle={'candidate':name,'weights':ws,'required_features':FEATURES,'training_rows':len(d),'training_composition_groups':len(set(groups)),'components':{k:trained[k] for k in ws},'note':'Full-data model selection scores are not independent performance estimates. Compare nested grouped results and source stress tests.'}
    joblib.dump(bundle,O/(label+'.joblib'),compress=3);loaded=joblib.load(O/(label+'.joblib'))
    # Only input features are supplied here; no measured UTS or elongation at inference.
    a=predict_saved_model(bundle,d[FEATURES].iloc[:8]);b=predict_saved_model(loaded,d[FEATURES].iloc[:8]);assert np.allclose(a.predicted_EL_percent,b.predicted_EL_percent)
    m={k:v for k,v in bundle.items() if k!='components'}
    m['neural_training']={k:c['bundle']['metadata'] for k,c in bundle['components'].items() if c['family']=='new' and c['bundle']['spec']['kind']=='neural'}
    meta[label]=m
(O/'Fitted_Model_Metadata.json').write_text(json.dumps(meta,indent=2));print('Selected',choices,flush=True)
