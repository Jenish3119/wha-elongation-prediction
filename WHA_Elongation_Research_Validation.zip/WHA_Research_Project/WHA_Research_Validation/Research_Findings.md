# WHA elongation: nested composition-grouped validation

This continuation focuses on prediction for unseen alloy compositions. It reconstructs a small candidate experiment from the available master dataset and original notebooks. The earlier V4 code and exact ensemble definition were not available, so this is not an exact reproduction of the earlier 0.5149 exploratory result.

## Data and protocol

- Input: 435 rows in Master_WHA_Dataset_Cleaned.xlsx; 433 retained after quarantining two composition totals outside 98–102%. No source values were edited.
- 183 composition groups, defined using all 12 elemental percentages rounded to four decimals. Every group stays entirely within a fold. Near-equivalent compositions beyond this precision may remain separate.
- Five outer GroupKFold folds and three inner GroupKFold folds. Median imputation and missingness indicators fit on training rows only. Elongation is the only target used.
- Fixed baseline: CatBoost, 500 iterations, depth 6, learning rate 0.05, seed 42. Candidates: raw target, square-root target (inverse prediction squared, without bias correction), 2× weight for training EL>24%, ExtraTrees, and square-root CatBoost/ExtraTrees blends with weights 0.25, 0.5 and 0.75 on CatBoost. Selection uses mean inner-fold R² only.
- Primary temperatures are retained exactly as supplied. Source labels and references are audit fields, not predictors. This is retrospective nested validation on previously explored data, not a new independent external test.

## Results

| Metric | Fixed baseline | Inner-selected procedure |
|---|---:|---:|
| Mean outer-fold R² | 0.5544 | 0.5726 |
| Fold R² standard deviation | 0.1680 | 0.1866 |
| Pooled OOF R² | 0.5576 | 0.5752 |
| OOF MAE (percentage points) | 4.361 | 4.169 |
| OOF RMSE (percentage points) | 5.926 | 5.807 |
| EL>24% MAE (percentage points, n=92) | 5.082 | 5.017 |

Mean fold R² and pooled OOF R² are different summaries and must not be interchanged. Group-bootstrap 95% interval for selected-minus-baseline pooled OOF R²: [-0.0039, 0.0377]. This interval conditions on the fitted OOF predictions and does not include all training/selection or prior exploration uncertainty.

The selected procedure improved mean outer-fold R². The paired interval crosses zero, so this experiment does not establish a consistent improvement.

## Data issues that affect the research interpretation

1. Excel row(s) in composition_review.csv: `80-7Ni-3Fe-10Mo` has parsed W=0 and sum=20. A missing W symbol is a plausible explanation, but the source must confirm it. `93W-7Ni-3Fe` sums to 103; do not normalize or guess a corrected composition.
2. Dataset 1 HT values span 1343–1523 while Dataset 2 spans 300–1300. This suggests a possible unit mismatch, but the original HT column did not name a unit. No automatic Kelvin conversion was made. temperature_sensitivity.csv measures how much the baseline depends on this ambiguous feature; it cannot determine the correct units.
3. HT temperature and duration each have 165 missing entries. Missing does not establish absence of heat treatment. The uploaded paper, Section 2.2 (PDF page 2), assigns 25°C/0 h specifically to samples without heat treatment. That rule cannot safely be applied to every blank in this merged workbook.
4. Preparation notebook drops original categorical fields including heat treatment type, quenching medium, swaging temperature, and test standard during column selection. Those fields cannot be recovered from the current master workbook. Original source workbooks and supplementary Table S1 are needed to restore them.
5. 110 records lack reference IDs. Composition grouping prevents identical-composition overlap but does not prevent shared-paper effects across different compositions. Literature-source grouping needs a complete, globally consistent reference mapping across both source datasets. Bracketed reference numbers are not globally unique citations.
6. Original notebook 03 reports UTS tuned holdout R²=0.8908 and elongation CatBoost holdout R²=0.6833 from random splits. These answer a different question from unseen-composition grouped validation and should not be compared directly with this table.
7. Original deployment predicts on all source rows, including rows seen during fitting. Such predictions are not independent validation and should not be presented as verified alloy recommendations. Pareto screening should follow data repair and use a separately validated design procedure.

## Next research actions

First verify temperature units and the two quarantined compositions against primary source tables, and restore missing processing fields from the original inputs. Then rerun this frozen protocol, followed by leave-study-out validation once references are complete. Use largest_errors.csv to prioritize source checking of high-error records; do not delete hard cases solely because their residuals are large. Choose any high-elongation-focused objective before the next outer evaluation. Final strength/ductility Pareto recommendations need validated models, feasibility constraints, and external measurements.

## Reproduction

Run `python run_analysis.py` beside an `inputs` folder containing the original master workbook. Dependencies: numpy, pandas, scikit-learn, catboost, matplotlib and an Excel reading engine. The script emits audit tables, all outer predictions, inner model choices, fold metrics, sensitivity results, plots and this report. No final production model was fitted in this validation step.
