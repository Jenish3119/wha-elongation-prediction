from pathlib import Path
import json, sys, platform, zipfile
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.impute import SimpleImputer
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from catboost import CatBoostRegressor
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'WHA_Research_Validation'; OUT.mkdir(exist_ok=True)
df=pd.read_excel(ROOT/'inputs/Master_WHA_Dataset_Cleaned.xlsx')
df.insert(0,'Excel row',np.arange(len(df))+2)
comp=[f'{e} (%)' for e in ['W','Ni','Fe','Co','Mo','Re','Cu','Mn','Cr','Ta','Hf','La']]
features=comp+['Sintering Temp (°C)','Sintering Time (hr)','Deformation Before HT (%)','HT Temp Standardized','HT Time (hr)','Post Deformation (%)']
total=df[comp].sum(axis=1)
bad=~total.between(98,102)
df.loc[bad].to_csv(OUT/'composition_review.csv',index=False)
d=df.loc[~bad].reset_index(drop=True)
groups=pd.factorize(d[comp].round(4).apply(tuple,axis=1))[0]
X=d[features].to_numpy(float); y=d['Elongation (%)'].to_numpy(float)
assert np.isfinite(y).all() and (y>=0).all()
audit={'input_rows':len(df),'included_rows':len(d),'excluded_rows':int(bad.sum()),'composition_groups':len(np.unique(groups)), 'composition_group_rounding_decimals':4,'target_nonmissing':df[['UTS (MPa)','Elongation (%)','Yield Strength (MPa)','Impact Toughness (J/cm²)','Hardness (HV)']].count().to_dict(),'missing_features':df[features].isna().sum().to_dict(),'exact_feature_duplicate_rows':int(df.duplicated(features).sum()),'reference_missing':int(df.Reference.isna().sum())}
json.dump(audit,open(OUT/'audit.json','w'),indent=2)
def model_prediction(kind,tr,te,xx=X):
    imp=SimpleImputer(strategy='median',add_indicator=True)
    a=imp.fit_transform(xx[tr]); b=imp.transform(xx[te])
    if kind=='extra':
        m=ExtraTreesRegressor(n_estimators=300,min_samples_leaf=2,max_features=1.0,random_state=42,n_jobs=2)
    else:
        m=CatBoostRegressor(iterations=500,depth=6,learning_rate=.05,random_seed=42,verbose=False,thread_count=2,allow_writing_files=False)
    target=np.sqrt(y[tr]) if kind=='sqrt' else y[tr]
    kw={'sample_weight':np.where(y[tr]>24,2.,1.)} if kind=='weighted' else {}
    m.fit(a,target,**kw)
    p=m.predict(b)
    return np.maximum(p,0)**2 if kind=='sqrt' else p
def metric(t,p):
    hi=t>24
    return {'R2':r2_score(t,p),'MAE_percentage_points':mean_absolute_error(t,p),'RMSE_percentage_points':float(np.sqrt(mean_squared_error(t,p))),'high_EL_n':int(hi.sum()),'high_EL_MAE_percentage_points':mean_absolute_error(t[hi],p[hi]) if hi.any() else np.nan}
kinds=['raw','sqrt','weighted','extra']
outer=GroupKFold(5)
oof={k:np.full(len(d),np.nan) for k in ['baseline','selected']}
folds=[];innerrows=[]; membership=np.zeros(len(d),int)
for fold,(tr,te) in enumerate(outer.split(X,y,groups),1):
    assert set(groups[tr]).isdisjoint(groups[te])
    print('Outer fold',fold,flush=True)
    innerpred={k:np.full(len(tr),np.nan) for k in kinds}
    innerfold=[]
    for j,(a,b) in enumerate(GroupKFold(3).split(X[tr],y[tr],groups[tr]),1):
        assert set(groups[tr[a]]).isdisjoint(groups[tr[b]])
        for k in kinds: innerpred[k][b]=model_prediction(k,tr[a],tr[b])
        innerfold.append(b)
    candidates=dict(innerpred)
    for w in [.25,.5,.75]: candidates[f'sqrt_extra_{w}']=w*innerpred['sqrt']+(1-w)*innerpred['extra']
    # Select only by average inner-validation R2; outer targets are never used here.
    scores={k:float(np.mean([r2_score(y[tr][b],p[b]) for b in innerfold])) for k,p in candidates.items()}
    winner=max(scores,key=scores.get)
    innerrows.extend({'outer_fold':fold,'candidate':k,'mean_inner_R2':v,'selected':k==winner} for k,v in scores.items())
    base=model_prediction('raw',tr,te)
    if winner.startswith('sqrt_extra_'):
        w=float(winner.rsplit('_',1)[1]);pred=w*model_prediction('sqrt',tr,te)+(1-w)*model_prediction('extra',tr,te)
    elif winner=='raw':pred=base
    else:pred=model_prediction(winner,tr,te)
    membership[te]=fold;oof['baseline'][te]=base;oof['selected'][te]=pred
    for name,p in [('baseline',base),('selected',pred)]:folds.append({'fold':fold,'model':name,'selected_candidate':winner if name=='selected' else 'raw','test_n':len(te),'train_groups':len(np.unique(groups[tr])),'test_groups':len(np.unique(groups[te])),**metric(y[te],p)})
    print(winner,'baseline',metric(y[te],base),'selected',metric(y[te],pred),flush=True)
pd.DataFrame(folds).to_csv(OUT/'outer_fold_metrics.csv',index=False)
pd.DataFrame(innerrows).to_csv(OUT/'inner_selection.csv',index=False)
summary=pd.DataFrame([{'model':k,**metric(y,p)} for k,p in oof.items()])
fm=pd.DataFrame(folds)
summary['mean_fold_R2']=[fm.loc[fm.model==k,'R2'].mean() for k in summary.model]
summary['std_fold_R2']=[fm.loc[fm.model==k,'R2'].std(ddof=1) for k in summary.model]
summary.to_csv(OUT/'summary_metrics.csv',index=False)
preds=d[['Excel row','Data Source','Original Composition','Reference','Elongation (%)']].copy()
preds['composition_group']=groups;preds['outer_fold']=membership
for k,p in oof.items():preds[k+'_OOF_prediction']=p;preds[k+'_absolute_error']=abs(y-p)
preds.to_csv(OUT/'out_of_fold_predictions.csv',index=False)
preds.sort_values('selected_absolute_error',ascending=False).head(30).to_csv(OUT/'largest_errors.csv',index=False)
# Group bootstrap describes uncertainty of paired OOF predictions, not a new independent test.
rng=np.random.default_rng(42);ug=np.unique(groups);delta=[]
for _ in range(2000):
    ix=np.concatenate([np.flatnonzero(groups==g) for g in rng.choice(ug,len(ug),replace=True)])
    delta.append(r2_score(y[ix],oof['selected'][ix])-r2_score(y[ix],oof['baseline'][ix]))
ci=np.quantile(delta,[.025,.975]);json.dump({'pooled_OOF_R2_difference_95pct_group_bootstrap_interval':ci.tolist(),'resamples':2000,'note':'Conditional on these retrospective OOF predictions. Not an independent test or correction for all previous exploration.'},open(OUT/'uncertainty.json','w'),indent=2)
# Predeclared diagnostic: remove ambiguous HT-temperature feature, same baseline and outer folds.
xx=d[[c for c in features if c!='HT Temp Standardized']].to_numpy(float)
sense=np.full(len(d),np.nan)
for tr,te in outer.split(X,y,groups):sense[te]=model_prediction('raw',tr,te,xx)
pd.DataFrame([{'variant':'HT temperature as supplied',**metric(y,oof['baseline'])},{'variant':'HT temperature omitted',**metric(y,sense)}]).to_csv(OUT/'temperature_sensitivity.csv',index=False)
preds['baseline_no_HT_temperature_OOF_prediction']=sense
preds.to_csv(OUT/'out_of_fold_predictions.csv',index=False)
fig,ax=plt.subplots(1,2,figsize=(11,4.4))
for a,k in zip(ax,['baseline','selected']):
    a.scatter(y,oof[k],s=19,alpha=.65,c=membership,cmap='viridis');lim=max(y.max(),oof[k].max())+1;a.plot([0,lim],[0,lim],'k--',lw=1);a.set(xlabel='Observed elongation (%)',ylabel='OOF predicted elongation (%)',title=k.capitalize(),xlim=(0,lim),ylim=(0,lim))
fig.tight_layout();fig.savefig(OUT/'OOF_elongation.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4))
for k in ['baseline','selected']:
    z=fm[fm.model==k];ax.plot(z.fold,z.R2,'o-',label=k)
ax.axhline(0,color='grey',lw=.7);ax.set(xlabel='Outer composition-grouped fold',ylabel='R²',title='Unseen-composition validation');ax.legend();fig.tight_layout();fig.savefig(OUT/'fold_R2.png',dpi=180);plt.close(fig)
b=summary[summary.model=='baseline'].iloc[0];s=summary[summary.model=='selected'].iloc[0]
report=f'''# WHA elongation: nested composition-grouped validation

This continuation focuses on prediction for unseen alloy compositions. It reconstructs a small candidate experiment from the available master dataset and original notebooks. The earlier V4 code and exact ensemble definition were not available, so this is not an exact reproduction of the earlier 0.5149 exploratory result.

## Data and protocol

- Input: 435 rows in Master_WHA_Dataset_Cleaned.xlsx; 433 retained after quarantining two composition totals outside 98–102%. No source values were edited.
- {len(np.unique(groups))} composition groups, defined using all 12 elemental percentages rounded to four decimals. Every group stays entirely within a fold. Near-equivalent compositions beyond this precision may remain separate.
- Five outer GroupKFold folds and three inner GroupKFold folds. Median imputation and missingness indicators fit on training rows only. Elongation is the only target used.
- Fixed baseline: CatBoost, 500 iterations, depth 6, learning rate 0.05, seed 42. Candidates: raw target, square-root target (inverse prediction squared, without bias correction), 2× weight for training EL>24%, ExtraTrees, and square-root CatBoost/ExtraTrees blends with weights 0.25, 0.5 and 0.75 on CatBoost. Selection uses mean inner-fold R² only.
- Primary temperatures are retained exactly as supplied. Source labels and references are audit fields, not predictors. This is retrospective nested validation on previously explored data, not a new independent external test.

## Results

| Metric | Fixed baseline | Inner-selected procedure |
|---|---:|---:|
| Mean outer-fold R² | {b.mean_fold_R2:.4f} | {s.mean_fold_R2:.4f} |
| Fold R² standard deviation | {b.std_fold_R2:.4f} | {s.std_fold_R2:.4f} |
| Pooled OOF R² | {b.R2:.4f} | {s.R2:.4f} |
| OOF MAE (percentage points) | {b.MAE_percentage_points:.3f} | {s.MAE_percentage_points:.3f} |
| OOF RMSE (percentage points) | {b.RMSE_percentage_points:.3f} | {s.RMSE_percentage_points:.3f} |
| EL>24% MAE (percentage points, n={int(b.high_EL_n)}) | {b.high_EL_MAE_percentage_points:.3f} | {s.high_EL_MAE_percentage_points:.3f} |

Mean fold R² and pooled OOF R² are different summaries and must not be interchanged. Group-bootstrap 95% interval for selected-minus-baseline pooled OOF R²: [{ci[0]:.4f}, {ci[1]:.4f}]. This interval conditions on the fitted OOF predictions and does not include all training/selection or prior exploration uncertainty.

The selected procedure {'improved' if s.mean_fold_R2>b.mean_fold_R2 else 'did not improve'} mean outer-fold R². {'The paired interval crosses zero, so this experiment does not establish a consistent improvement.' if ci[0]<=0<=ci[1] else 'The paired interval excludes zero, but additional external validation is still needed before claiming a robust generalization gain.'}

## Data issues that affect the research interpretation

1. Excel row(s) in composition_review.csv: `80-7Ni-3Fe-10Mo` has parsed W=0 and sum=20. A missing W symbol is a plausible explanation, but the source must confirm it. `93W-7Ni-3Fe` sums to 103; do not normalize or guess a corrected composition.
2. Dataset 1 HT values span 1343–1523 while Dataset 2 spans 300–1300. This suggests a possible unit mismatch, but the original HT column did not name a unit. No automatic Kelvin conversion was made. temperature_sensitivity.csv measures how much the baseline depends on this ambiguous feature; it cannot determine the correct units.
3. HT temperature and duration each have 165 missing entries. Missing does not establish absence of heat treatment. The uploaded paper, Section 2.2 (PDF page 2), assigns 25°C/0 h specifically to samples without heat treatment. That rule cannot safely be applied to every blank in this merged workbook.
4. Preparation notebook drops original categorical fields including heat treatment type, quenching medium, swaging temperature, and test standard during column selection. Those fields cannot be recovered from the current master workbook. Original source workbooks and supplementary Table S1 are needed to restore them.
5. {audit['reference_missing']} records lack reference IDs. Composition grouping prevents identical-composition overlap but does not prevent shared-paper effects across different compositions. Literature-source grouping needs a complete, globally consistent reference mapping across both source datasets. Bracketed reference numbers are not globally unique citations.
6. Original notebook 03 reports UTS tuned holdout R²=0.8908 and elongation CatBoost holdout R²=0.6833 from random splits. These answer a different question from unseen-composition grouped validation and should not be compared directly with this table.
7. Original deployment predicts on all source rows, including rows seen during fitting. Such predictions are not independent validation and should not be presented as verified alloy recommendations. Pareto screening should follow data repair and use a separately validated design procedure.

## Next research actions

First verify temperature units and the two quarantined compositions against primary source tables, and restore missing processing fields from the original inputs. Then rerun this frozen protocol, followed by leave-study-out validation once references are complete. Use largest_errors.csv to prioritize source checking of high-error records; do not delete hard cases solely because their residuals are large. Choose any high-elongation-focused objective before the next outer evaluation. Final strength/ductility Pareto recommendations need validated models, feasibility constraints, and external measurements.

## Reproduction

Run `python run_analysis.py` beside an `inputs` folder containing the original master workbook. Dependencies: numpy, pandas, scikit-learn, catboost, matplotlib and an Excel reading engine. The script emits audit tables, all outer predictions, inner model choices, fold metrics, sensitivity results, plots and this report. No final production model was fitted in this validation step.
'''
(OUT/'Research_Findings.md').write_text(report)
(OUT/'environment.json').write_text(json.dumps({'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'platform':platform.platform()},indent=2))
print(summary.to_string(index=False),flush=True);print('CI',ci,flush=True)
