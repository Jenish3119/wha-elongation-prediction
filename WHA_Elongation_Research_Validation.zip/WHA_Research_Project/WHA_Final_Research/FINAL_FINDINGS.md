# Final WHA elongation research analysis

Read `WHA_Elongation_Final_Report.pdf` or the editable Word version first. The report covers the complete computational work, quantitative conclusions and unresolved scientific inputs.

Completed work includes data audit, composition quarantine, nested composition-grouped selection, repeat validation, error-focused weighting, reported-reference stress testing with shared-composition purging, retrospective literature-record checking, and held-out joint block interpretation. Both fitted model options and all earlier analyses are retained.

The balanced objective reduced high-EL MAE by approximately 14% and 20% on the two composition partitions, at a small R² cost. In the stricter Dataset 2 reference-label stress test, pooled R² was 0.1243 for the ensemble and 0.0313 for weighted ExtraTrees, with MAE 6.817 and 6.994 percentage points. The smaller training sets and different subset prevent a direct comparison with the nested scores.

The three-record retrospective pilot has frozen-model MAE 5.526 and 4.654 percentage points. It comes from the already-seen source paper and has an unknown HT temperature. It is not independent external validation.

Deformation and composition have the highest measured predictive reliance in held-out block permutation. This is a model diagnostic, not causal metallurgy. The original workbook is unchanged and no unverified source correction was applied.

Original raw processing files, temperature unit annotations, verified corrections for the two questionable compositions, a complete citation map and a genuinely independent complete test set remain unavailable. Their status is explicitly recorded rather than marked complete.

## Run

From the extracted project root, run `python finalize_research.py`. For new predictions use `python predict_tail.py input.xlsx output.csv` or `python predict_elongation.py input.xlsx output.csv`. Follow the feature schema and limitations in the report. The latest notebook is `08_Final_Research_Analysis.ipynb`.
