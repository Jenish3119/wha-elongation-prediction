# WHA elongation improvement study

## Outcome

The expanded procedure improved mean composition-grouped R² on both evaluated partitions. The gains are modest and not statistically established. The original-fold MAE worsened slightly, the shuffled-fold MAE improved, and high-elongation errors did not improve. Keep both results when reporting this study. No new external dataset was used.

## Validation results

All MAE values below are in elongation percentage points. Each partition uses 5 outer composition-grouped folds with 3 inner folds for model selection. The original partition reproduces the previous predictions exactly. The shuffled partition uses seed 2026 for both outer and inner grouping. It is a robustness check on the same 433 rows, not an independent test dataset.

| Partition | Procedure | Mean outer-fold R² | Pooled OOF R² | OOF MAE | EL>24% MAE |
|---|---|---:|---:|---:|---:|
| Original | Fixed baseline | 0.5544 | 0.5576 | 4.361 | 5.082 |
| Original | Previous selection | 0.5726 | 0.5752 | 4.169 | 5.017 |
| Original | Expanded selection | 0.5765 | 0.5812 | 4.208 | 5.256 |
| Shuffled 2026 | Fixed baseline | 0.4608 | 0.4515 | 4.900 | 5.718 |
| Shuffled 2026 | Previous selection | 0.4900 | 0.4699 | 4.687 | 6.101 |
| Shuffled 2026 | Expanded selection | 0.5176 | 0.5164 | 4.561 | 6.113 |

The paired group-bootstrap 95% intervals for expanded-minus-previous pooled OOF R² are [-0.0402, 0.0555] on the original partition and [-0.0167, 0.1141] on the shuffled partition. Both cross zero. These intervals condition on already fitted OOF predictions and do not include every source of model-selection uncertainty. Prior exploration of this dataset also limits independent performance claims.

## What changed

Twelve additional deterministic features were derived from the existing composition and processing columns: non-W total, Ni+Fe+Co total, Ni/Fe ratio, Fe-absence flag, Ni and Co fractions of Ni+Fe+Co, Mo+Re+Ta total, a sequential-deformation proxy, a pre/post-deformation interaction, a deformation/binder interaction, and log-transformed sintering and HT durations. The deformation proxy assumes compatible percentage reductions at the two stages; it is an exploratory predictor, not a verified physical strain measurement. Ni/Fe remains missing when Fe=0, with a separate absence flag. No target values enter any feature.

The frozen candidate set has 24 entries: the original seven choices plus regularized CatBoost variants, raw and square-root targets, ExtraTrees, Random Forest, SVR, an HT-temperature omission variant, and fixed weighted ensembles. CatBoost engineered variants preserve native missing values. Other models use median imputation and missingness indicators fitted inside each training fold. SVR scaling also fits inside the training fold. Model and ensemble selection uses mean inner-fold R² only. Every composition group stays within one fold. All original candidates remain eligible. No rows were removed based on prediction error, and no outer-fold results were used to tune candidate parameters during these runs.

## Data repair and recovery status

- The two questionable compositions remain quarantined: Excel rows 304 and 331 in the original workbook. Their totals are 20% and 103%. No composition was guessed or renormalized.
- The original master workbook is unchanged. Its SHA-256 is recorded in the experiment plan.
- HT temperature units remain unresolved. Reported Dataset 1 values differ systematically from Dataset 2; neither source-specific conversion nor replacement of blank HT entries with 'no treatment' was performed.
- Original processing source files were not located through the available search. The paper's supplementary file could not be retrieved during this run because the publisher access returned HTTP 403. Quenching medium, HT type, swaging temperature and ageing details therefore could not be restored. Current encoded features do not reconstruct these missing facts.
- There are 21 groups comprising 61 records with identical available input vectors. In the largest conflicting example, 92W-5Ni-3Co has eight such records with elongation ranging from 6% to 23%. Missing processing/test details or measurement differences may explain this, but this audit cannot establish the cause. Records remain in the analysis.
- References are still absent for 110 rows. Composition grouping does not guarantee that different compositions from the same paper are separated. A full leave-study-out test requires a complete source map.

## Final fitted model

The same frozen candidate selection was run with three composition-grouped folds on all 433 eligible records, then the selected candidate was refitted on all those records. This full-data selection score is not a new estimate of generalization performance.

The selected model is `eng_sqrt_blend_0.25`: 25% regularized square-root CatBoost and 75% ExtraTrees with engineered inputs. It is stored in `WHA_Improvement/Elongation_Model.joblib`. The fixed CatBoost component uses depth 4, 800 iterations, learning rate 0.03 and L2 regularization 10. ExtraTrees uses 500 trees and minimum leaf size 2. The square-root prediction is squared without a bias correction. The model is a research artifact; the unresolved temperature/data limitations still apply. Its full-data fitted predictions must not be used as independent validation evidence.

`elongation_predictor.py` reproduces feature generation and inference. Required input fields are listed in `model_metadata.json`. Zero elemental content must be explicit. Missing element percentages cause a clear error; composition totals outside 98–102% produce no prediction and a review flag. Missing numeric processing fields can remain NaN. Training feature ranges are retained in model metadata for review.

## Reproduce and use

Extract the package, install the pinned dependencies in `requirements.txt`, and run commands from the extracted project folder:

```bash
python improve_elongation.py
python improve_elongation.py --repeat
python final_fit_elongation.py
python predict_elongation.py input.xlsx predictions.csv
```

The inference command estimates elongation only. It does not optimize alloy designs or establish strength–ductility recommendations. `06_Elongation_Improvement.ipynb` offers the same workflow. The original analysis is retained under `WHA_Research_Validation/`.

## Checks completed

The previous OOF predictions were reproduced exactly on the original partition. Both new nested evaluations contain 433 complete OOF records per procedure, one held-out assignment per composition group, and exactly one inner-selected candidate per outer fold. Standalone inference features match the experimental features. The saved model was reloaded, its predictions matched the original fitted object, and invalid-composition behavior was checked. The comparison figures were visually inspected.

## Research interpretation

The added features and regularization provide a modest R² gain across the two tested partitions, rather than a demonstrated major accuracy breakthrough. High-elongation errors remain a limitation. Source data recovery and temperature verification are the next meaningful improvements. Re-run the frozen protocol after those corrections and obtain an external or fully mapped leave-study-out evaluation before making stronger performance claims.

Primary paper associated with Dataset 2: https://doi.org/10.1016/j.matdes.2026.115545 . This run used the already uploaded master dataset and paper; no supplementary observations were added.
