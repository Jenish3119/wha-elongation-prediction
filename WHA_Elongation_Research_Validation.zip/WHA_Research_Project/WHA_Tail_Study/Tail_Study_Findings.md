# WHA: high-elongation error reduction

## Outcome

The constrained balanced selection reduced high-elongation MAE by about 14% and 20% on the two tested composition partitions. It also reduced overall MAE on both partitions. Mean outer-fold R² fell slightly. This is a measured trade-off between absolute prediction error and squared-error performance, not an overall R² breakthrough. The previous higher-R² model is retained. All experiments reuse the same previously explored dataset.

## Results

There are 433 eligible records, 183 composition groups and 92 records with observed EL>24%. MAE is reported in elongation percentage points. Mean fold R² and pooled OOF R² are different summaries; the table uses mean fold R² consistently.

| Partition | Selection objective | Mean fold R² | Overall MAE | EL>24% MAE | High-EL MAE reduction |
|---|---|---:|---:|---:|---:|
| Original | reference | 0.5765 | 4.208 | 5.256 | 0.0% |
| Original | tail_focus | 0.5479 | 4.202 | 4.526 | 13.9% |
| Original | balanced_focus | 0.5597 | 4.154 | 4.529 | 13.8% |
| Shuffled 2026 | reference | 0.5176 | 4.561 | 6.113 | 0.0% |
| Shuffled 2026 | tail_focus | 0.4838 | 4.641 | 4.646 | 24.0% |
| Shuffled 2026 | balanced_focus | 0.5126 | 4.404 | 4.902 | 19.8% |

The balanced objective gives most of the high-elongation benefit with a smaller R² cost. The tail-only objective reduces high-EL error further on the shuffled partition, but has a larger overall R² cost and a slightly higher overall MAE there. Inner constraints do not guarantee corresponding outer-test constraints.

## Protocol and candidate changes

The same original 5-fold and shuffled 5-fold outer composition partitions were reused. Each outer training set has 3 composition-grouped inner folds. The previous expanded candidate set and its predictions were reproduced exactly as the reference in both partitions.

Eleven new candidate estimators were added to the previous 24 choices, giving 35 candidates. New choices apply 2× or 3× training weight to rows with EL>24%, inverse-frequency weighting of training composition groups, or a combination. Weighting uses training labels and training-group counts only. Predicting a new row never requires knowing whether its true elongation is high.

Two new selection objectives were fixed before this round's outer results:

1. `tail_focus`: minimize pooled inner-validation MAE on EL>24%.
2. `balanced_focus`: minimize the equal-weight mean of inner MAEs for EL<=10%, 10%<EL<=24%, and EL>24%.

Both use the same eligibility guards: mean inner R² must be within 0.02 of the prior R²-selected reference, and pooled inner overall MAE must be no more than 3% above the reference. The reference itself is eligible, providing a fallback. Outer labels are used only to evaluate the frozen selections. Median imputation, missingness indicators, scaling and any native missing-value handling remain inside the training workflow. No source values were changed and no difficult records were dropped.

## Uncertainty

The following paired composition-bootstrap intervals describe differences in high-EL MAE relative to the reference. Negative differences indicate lower MAE. They condition on fitted OOF predictions, not on a new external sample or every possible training run.

| Partition | Objective | 95% interval for high-EL MAE difference (pp) |
|---|---|---|
| Original | tail_focus | [-1.063, -0.408] |
| Original | balanced_focus | [-1.060, -0.389] |
| Shuffled 2026 | tail_focus | [-2.038, -0.956] |
| Shuffled 2026 | balanced_focus | [-1.606, -0.789] |

All intervals are below zero, providing evidence of high-EL error reduction within these retrospective evaluations. This does not establish performance on an independent literature collection. Repeated exploration of this dataset limits stronger claims.

## Composition-distance diagnostic

For every held-out record, the Euclidean distance in the 12 elemental wt.% values to the nearest training composition was computed using training inputs only. Held-out distances were split into three descriptive quantile bins. These bins are an audit, not a new model-selection rule or a calibrated confidence measure.

For the balanced procedure, far-bin overall MAE is 5.24 pp on the original partition and 5.62 pp on the shuffled partition. Near-bin MAE is 3.72 and 3.40 pp, respectively. This is consistent with higher error on less-represented composition regions. It does not explain all error or resolve missing processing details. Distances describe composition only, not process similarity. Exact bin counts and distance ranges are in `composition_distance_diagnostics.csv`.

## Fitted model and use

Both objectives selected the same candidate during a separate 3-fold selection over all 433 eligible rows: `eng_extra_high3`. The resulting alternative model is an ExtraTrees regressor with 500 trees, minimum leaf size 2, engineered inputs, median imputation and missingness indicators. High-elongation training rows receive 3× weight. No high-EL label is used at inference.

The model is stored in `WHA_Tail_Study/High_Elongation_Model.joblib`. The previous model remains in `WHA_Improvement/Elongation_Model.joblib`. Full-data selection scores and fitted predictions are not independent validation evidence. The nested results describe selection procedures; a single final fitted estimator has not been externally validated.

Run from the extracted project root:

```bash
python advance_tail.py
python advance_tail.py --repeat
python fit_tail_model.py
python predict_tail.py new_inputs.xlsx predictions.csv
```

`07_High_Elongation_Study.ipynb` provides the same workflow. Input columns and temperature conventions are unchanged. The inference wrapper rejects missing elemental percentages and leaves predictions blank for composition totals outside 98–102%. It does not silently correct units or composition. `predict_elongation.py` still uses the previous model.

## Checks and remaining limits

Both reference OOF arrays exactly match the previous expanded study. Every outer composition group remains isolated, and every eligible row has a held-out prediction for all three procedures. Exactly one candidate is selected per objective per outer fold, and the inner guards were verified. The alternate model was saved, reloaded, and checked on complete and invalid-composition inputs. Figures were visually inspected.

Temperature units, missing original processing categories, two quarantined compositions, conflicting identical-input records and incomplete literature references remain unresolved. No new primary-source records were recovered during this round. These are still the main limits to stronger generalization and source-grouped validation. The higher-R² model and this lower-high-EL-error alternative should remain separately labelled. Neither is a demonstrated universal replacement for the other.
