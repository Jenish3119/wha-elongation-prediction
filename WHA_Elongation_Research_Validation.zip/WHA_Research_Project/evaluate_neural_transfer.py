"""Retrospective reference-label stress test of frozen full-data selected recipes."""
from pathlib import Path
import json,hashlib,joblib,sys
import numpy as np,pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error
from advanced_models import fit_method,predict_saved_model
from elongation_predictor import COMP,fit_component
R=Path(__file__).resolve().parent;O=R/'WHA_Neural_Study'
if '--phase-b' in sys.argv:O=O/'phase_b'
labels=['Research_Selected_Model','Neural_Model'];templates={k:joblib.load(O/(k+'.joblib')) for k in labels}
(O/'Transfer_Frozen_Model_Hashes.json').write_text(json.dumps({k:hashlib.sha256((O/(k+'.joblib')).read_bytes()).hexdigest() for k in labels},indent=2))
raw=pd.read_excel(R/'inputs/Master_WHA_Dataset_Cleaned.xlsx');raw.insert(0,'Excel row',np.arange(len(raw))+2);d=raw[(raw['Data Source']=='Dataset 2')&raw[COMP].sum(axis=1).between(98,102)].reset_index(drop=True)
y=d['Elongation (%)'].to_numpy(float);aux=d['UTS (MPa)'].to_numpy(float);refs=d.Reference.astype(str).str.replace('\xa0','',regex=False).str.strip().to_numpy();keys=d[COMP].round(4).apply(tuple,axis=1).to_numpy();groups=pd.factorize(keys)[0]
oo={k:np.full(len(d),np.nan) for k in labels};folds=[];fid=np.zeros(len(d),int)
def metric(t,p):return {'n':len(t),'R2':float(r2_score(t,p)),'MAE_pp':float(mean_absolute_error(t,p)),'RMSE_pp':float(np.sqrt(mean_squared_error(t,p)))}
for f,(tr0,te) in enumerate(GroupKFold(5).split(d,y,refs),1):
    test=set(keys[te]);tr=np.array([i for i in tr0 if keys[i] not in test]);assert set(refs[tr]).isdisjoint(refs[te]);assert set(keys[tr]).isdisjoint(keys[te]);trained={}
    for label,template in templates.items():
        for k,c in template['components'].items():
            if k not in trained:
                spec=c['bundle']['spec'];obj=fit_method(spec,d.iloc[tr],y[tr],aux[tr],groups[tr]) if c['family']=='new' else fit_component(d.iloc[tr],y[tr],spec)
                trained[k]={'family':c['family'],'bundle':obj}
        fitted={'weights':template['weights'],'components':{k:trained[k] for k in template['weights']}};p=predict_saved_model(fitted,d.iloc[te]).predicted_EL_percent.to_numpy();oo[label][te]=p
        folds.append({'fold':f,'model':label,'candidate':template['candidate'],'train_n':len(tr),'purged_n':len(tr0)-len(tr),**metric(y[te],p)})
    fid[te]=f;print('Purged reference stress fold',f,'completed',flush=True)
pd.DataFrame(folds).to_csv(O/'Reference_Stress_Fold_Metrics.csv',index=False)
summary=pd.DataFrame([{'model':k,**metric(y,p)} for k,p in oo.items()]);summary.to_csv(O/'Reference_Stress_Comparison.csv',index=False)
out=d[['Excel row','Reference','Elongation (%)']].copy();out['fold']=fid
for k,p in oo.items():out[k+'_prediction']=p
out.to_csv(O/'Reference_Stress_Predictions.csv',index=False)
previous=pd.read_csv(R/'WHA_Final_Research/Purged_Reference_Predictions.csv');assert np.array_equal(previous['Excel row'],out['Excel row']) and np.array_equal(previous.fold,out.fold)
pilot=pd.read_csv(R/'WHA_Final_Research/Retrospective_Three_Record_Pilot.csv');pm=[]
for label,bundle in templates.items():
    p=predict_saved_model(bundle,pilot).predicted_EL_percent.to_numpy();pilot[label+'_prediction']=p;pm.append({'model':label,**metric(pilot['Observed EL (%)'].to_numpy(),p)})
pilot.to_csv(O/'Retrospective_Pilot_Predictions.csv',index=False);pd.DataFrame(pm).to_csv(O/'Retrospective_Pilot_Metrics.csv',index=False)
print('Reference stress',summary.to_string(index=False),flush=True);print('Pilot',pd.DataFrame(pm).to_string(index=False),flush=True)
