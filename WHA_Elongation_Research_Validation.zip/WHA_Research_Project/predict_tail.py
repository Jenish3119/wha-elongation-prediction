"""Usage: python predict_tail.py input.xlsx output.csv"""
from pathlib import Path
import sys,joblib,pandas as pd
from elongation_predictor import predict
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit(__doc__)
    root=Path(__file__).resolve().parent
    bundle=joblib.load(root/'WHA_Tail_Study/High_Elongation_Model.joblib')
    path=Path(sys.argv[1]);data=pd.read_excel(path) if path.suffix.lower()=='.xlsx' else pd.read_csv(path)
    results=predict(bundle,data);out=data.copy()
    for col in results:out[col]=results[col]
    out.to_csv(sys.argv[2],index=False)
    print('Saved',len(out),'rows to',sys.argv[2])
