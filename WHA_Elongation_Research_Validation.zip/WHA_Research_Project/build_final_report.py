from pathlib import Path
import json
import pandas as pd
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

R=Path(__file__).resolve().parent;O=R/'WHA_Final_Research'
doc=Document();sec=doc.sections[0];sec.page_height=Inches(11.7);sec.page_width=Inches(8.3);sec.top_margin=sec.bottom_margin=Inches(.72);sec.left_margin=sec.right_margin=Inches(.8)
normal=doc.styles['Normal'];normal.font.name='Calibri';normal.font.size=Pt(11);normal.paragraph_format.space_after=Pt(7);normal.paragraph_format.line_spacing=1.1
for name,size in [('Title',25),('Heading 1',17),('Heading 2',12)]:
    st=doc.styles[name];st.font.name='Calibri';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0);st.paragraph_format.space_before=Pt(8);st.paragraph_format.space_after=Pt(8)
doc.styles['Caption'].font.size=Pt(9);doc.styles['Caption'].font.color.rgb=RGBColor.from_string('555555')
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
run=footer.add_run();field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');run._r.addnext(field)
def p(s,style=None):return doc.add_paragraph(s,style)
def h(s):return doc.add_heading(s,level=1)
def page(s):doc.add_page_break();h(s)
def table(headers,rows,widths=None):
    t=doc.add_table(rows=1,cols=len(headers));t.style='Light Shading Accent 1';t.autofit=False
    if widths:
        for col,width in zip(t.columns,widths):col.width=Inches(width)
    for i,x in enumerate(headers):t.rows[0].cells[i].text=str(x)
    trpr=t.rows[0]._tr.get_or_add_trPr();repeat=OxmlElement('w:tblHeader');trpr.append(repeat)
    for row in rows:
        for cell,x in zip(t.add_row().cells,row):cell.text=str(x)
    for ri,row in enumerate(t.rows):
        for ci,cell in enumerate(row.cells):
            if widths:cell.width=Inches(widths[ci])
            for para in cell.paragraphs:
                para.paragraph_format.space_after=Pt(4);para.paragraph_format.space_before=Pt(3)
                for run in para.runs:run.font.size=Pt(9.5);run.bold=ri==0;run.font.color.rgb=RGBColor(0,0,0)
            if ri==0:
                tcpr=cell._tc.get_or_add_tcPr();sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E8F1F1');tcpr.append(sh)
        keep=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(keep)
    p('');return t
def image(path,width=6.5,caption=''):
    para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=para.add_run();run.add_picture(str(path),width=Inches(width))
    if caption:p(caption,'Caption')

orig=pd.read_csv(R/'WHA_Tail_Study/comparison.csv').set_index('procedure');rep=pd.read_csv(R/'WHA_Tail_Study/robustness/comparison.csv').set_index('procedure')
stress=pd.read_csv(O/'Purged_Reference_Pooled_Metrics.csv');pilot=pd.read_csv(O/'Retrospective_Three_Record_Pilot.csv');pm=pd.read_csv(O/'Pilot_Metrics.csv').set_index('model');imp=pd.read_csv(O/'Heldout_Block_Importance.csv')

doc.add_heading('Prediction of Elongation in Tungsten Heavy Alloys',0)
p('Research analysis report  |  22 October 2026')
doc.add_heading('Abstract',level=1)
p('This study evaluates elongation prediction from nominal composition and processing information in tungsten heavy alloys. The compiled dataset contains 435 records from two sources. Two questionable compositions were quarantined, leaving 433 records and 183 distinct composition groups. Nested composition-grouped validation compared predictive models, engineered features and training weights. A balanced error objective reduced high-elongation mean absolute error by approximately 14% and 20% on two tested partitions, with a small decrease in mean fold R². A stricter reference-label holdout with shared compositions removed from training produced much weaker results. A three-record retrospective check from the supplied paper also showed underprediction. The work establishes reproducible research prototypes and quantifies their current limitations. Source verification and genuinely independent external validation remain necessary.')
h('Main findings')
for s in ['Balanced selection reduced EL >24% MAE from 5.26 to 4.53 percentage points on the original folds and from 6.11 to 4.90 on the shuffled folds.','Overall MAE improved on both partitions, while mean fold R² changed from 0.5765 to 0.5597 and from 0.5176 to 0.5126.','On the stricter reported-reference test, pooled R² was 0.1243 for the ensemble recipe and 0.0313 for weighted ExtraTrees. This setup also uses a different subset and smaller training sets.','Held-out joint permutation identified deformation and composition as the strongest input blocks for the balanced selection procedure.','No source correction was accepted without evidence. Unknown HT units, omitted processing fields and incomplete reference mapping remain open.']:p(s,'List Bullet')
h('Scope')
p('The prediction target in this report is elongation. UTS, yield strength, impact toughness and hardness remain in the preserved source workbook, but are not jointly validated by this final elongation study. No new physical experiments were performed.')

page('Data provenance and quality')
p('The starting file is Master_WHA_Dataset_Cleaned.xlsx. Dataset 1 contributes 110 records and Dataset 2 contributes 325. The preparation notebooks show that the merged feature selection omitted several original processing fields. The original values are preserved; the audited modeling table is supplied as CSV with record identifiers and explicit review flags.')
table(['Item','Count or status','Treatment'],[['Original records','435','Preserved'],['Eligible records','433','Used for modeling'],['Composition groups','183','All 12 elements rounded to four decimals'],['HT temperature and time missing','165 records each','Unknown; not automatically untreated'],['Dataset 1 records without references','110','Citation restoration required'],['Identical available input groups','21 groups and 61 records','Retained without averaging targets'],['Verified source edits in this final study','0','No inferred corrections applied']],[2.5,1.4,2.7])
p('Excel row 304 contains the string 80-7Ni-3Fe-10Mo with parsed W=0 and a composition total of 20%. Excel row 331 contains 93W-7Ni-3Fe, totaling 103%. Both remain quarantined. A plausible intended value is not sufficient evidence for changing a scientific record.')
p('Dataset 1 has 106 populated HT temperature values between 1343 and 1523, while Dataset 2 values span 300 to 1300. The difference suggests a possible unit mismatch but does not establish it. The final models retain the supplied field. An earlier provisional Kelvin conversion is not treated as a verified correction.')
p('The largest identical-input conflict involves eight records for 92W-5Ni-3Co, with elongation ranging from 6% to 23%. Omitted process conditions, testing differences or measurement variability may contribute. The data do not establish which explanation is responsible. These observations should not be deleted merely because they are difficult to predict.')

page('Methods')
p('Tungsten heavy alloys combine tungsten-rich particles with a metallic binder. Nominal composition and processing therefore provide useful predictors, but they do not directly measure phase morphology, interfaces or damage. Models were evaluated on held-out compositions to reduce the benefit of repeating an alloy composition across training and testing.')
doc.add_heading('Inputs and engineered descriptors',level=2)
p('The baseline contains 12 elemental concentrations and six processing inputs: sintering temperature and time, deformation before HT, reported HT temperature, HT time and post-deformation. Twelve additional descriptors include Ni+Fe+Co total, non-W total, Ni/Fe ratio with an Fe-absence flag, binder ratios, refractory additions, deformation interactions and log durations. These are exploratory descriptors rather than measured microstructure or verified strain. No target value enters feature generation.')
doc.add_heading('Nested validation',level=2)
for s in ['Five outer GroupKFold folds estimate performance on held-out composition groups. Three inner grouped folds select candidate models and ensemble weights within each outer training set.','A second five-fold partition shuffles groups with seed 2026. Both partitions use the same records and are not independent datasets.','Imputation, indicators and scaling are fitted inside each training fold. Engineered CatBoost variants can retain native missing values. GroupKFold keeps a group in one fold [4].','The earlier expanded study compares 24 choices. The error-focused extension compares 35 choices, adding higher weights for EL>24% training rows and inverse-frequency composition-group weights.']:p(s,'List Number')
doc.add_heading('Selection objectives',level=2)
p('The reference procedure maximizes mean inner R². Tail-focused selection minimizes inner MAE for EL>24%. Balanced selection minimizes the equal-weight mean MAE in three observed target ranges: EL<=10%, 10%<EL<=24% and EL>24%. Eligibility requires mean inner R² within 0.02 of the reference and overall inner MAE no more than 3% above it. These inner limits do not guarantee identical outer-test limits.')
doc.add_heading('Metrics and interpretation',level=2)
p('MAE is the mean absolute observed-predicted difference. For elongation it is reported in percentage points. RMSE gives greater weight to large errors. R² compares squared prediction error with observed target variability; it is not a percentage of exact predictions. Mean fold R² and R² calculated from all pooled held-out predictions are reported separately.')

page('Composition grouped validation results')
rows=[]
for name,x in [('Original',orig),('Shuffled',rep)]:
    for key,label in [('reference','Reference'),('balanced_focus','Balanced'),('tail_focus','Tail focused')]:
        s=x.loc[key];rows.append([name,label,f'{s.mean_fold_R2:.4f}',f'{s.MAE_pp:.3f}',f'{s.high_EL_MAE_pp:.3f}'])
table(['Partition','Objective','Mean fold R²','Overall MAE pp','High EL MAE pp'],rows,[1.05,1.25,1.35,1.4,1.55])
image(R/'WHA_Tail_Study/high_EL_tradeoff.png',6.5,'Figure 1  Balanced selection lowers high-elongation error with a small R² cost. All comparisons are within the same partition.')
p('Balanced selection gives most of the high-elongation benefit with a smaller R² cost than tail-only selection. Its overall MAE is also lower on both tested partitions. The original-fold mean R² is 0.5597 and the shuffled-fold mean is 0.5126; choosing the more favorable partition would overstate performance.')
p('Paired composition-bootstrap intervals for the balanced high-EL MAE difference are [-1.060, -0.389] pp on the original partition and [-1.606, -0.789] pp on the shuffled partition. Negative differences favor balanced selection. These intervals condition on the fitted held-out predictions and do not account for all training variability or repeated exploration of this dataset.')

page('Stricter validation and literature pilot')
p('The stricter test uses only the 323 eligible Dataset 2 rows with 52 local reference labels. Five folds separate those labels; training then removes every composition appearing in the held-out fold. Training sizes are 206-221 rows, with 37-52 additional rows purged per fold. Local reference labels have not been mapped to verified global publication identities, so this is a reported-reference stress test rather than verified publication-wise validation. Fixed model recipes are refitted without further tuning.')
labels={'higher_R2_recipe':'Fixed ensemble','weighted_ExtraTrees':'Weighted ExtraTrees','training_mean':'Training mean'}
table(['Recipe','Pooled R²','MAE pp','High EL MAE pp'],[[labels[s.model],f'{s.R2:.4f}',f'{s.MAE_pp:.3f}',f'{s.high_EL_MAE_pp:.3f}'] for s in stress.itertuples()],[2.4,1.25,1.3,1.65])
p('The weak scores show limited generalization under this more restrictive setup. They are not directly comparable with the 433-row nested results because the subset, recipe-selection history, training size and split scheme differ. Both learned recipes improve over the training-mean baseline, but their errors remain substantial.')
doc.add_heading('Three record retrospective check',level=2)
p('Three experimental alloy means in Fu et al. [1] are outside the master workbook by composition. Inputs come from Table 2 on PDF page 7; measured elongations come from Table 4 on page 11. The paper states that deformation effects were excluded from experimental validation, supporting zero pre- and post-deformation. HT temperature is not specified in these tables and remains missing. Published means carry reported ±1 pp values, whose statistical interpretation is not reassigned here.')
table(['Record','Published EL %','Ensemble prediction %','Weighted prediction %'],[[s['Sample'],f"{s['Observed EL (%)']:.1f}",f"{s['higher_R2 prediction (%)']:.2f}",f"{s['error_focused prediction (%)']:.2f}"] for _,s in pilot.iterrows()],[1.,1.6,2.,2.])
p(f"The frozen ensemble MAE is {pm.loc['higher_R2','MAE_pp']:.3f} pp and weighted-model MAE is {pm.loc['error_focused','MAE_pp']:.3f} pp. Both underpredict all three observations. R² values are negative and unstable at n=3; the exact values are retained in Pilot_Metrics.csv. The paper was already seen, the samples were selected by its authors, and an input is missing. This check is not blind or independent external validation.")

page('Held out feature analysis')
p('Joint block permutation measures how much held-out predictive performance changes when one input block is shuffled. Composition is permuted as a complete vector so its total remains intact. Sintering, HT and deformation pairs are each shuffled jointly, and derived features regenerate from the modified raw inputs. Ten permutations per block were evaluated in each of ten outer folds of the balanced selection procedure.')
image(O/'Heldout_Block_Importance.png',6.4,'Figure 2  Bars show mean held-out R² loss after permutation. Error bars show descriptive variation across ten folds, not independent confidence intervals.')
table(['Input block','Mean R² drop','Fold SD','Mean MAE rise pp'],[[s.block,f'{s.mean_R2_drop:.3f}',f'{s.fold_SD_R2_drop:.3f}',f'{s.mean_MAE_increase_pp:.3f}'] for s in imp.itertuples()],[2.,1.5,1.25,1.85])
p('Deformation has the strongest measured predictive reliance, followed by composition. All four blocks produce a positive average R² decrease in every tested fold. Correlation among blocks means their importances are not additive and do not represent independent causal effects. Shuffling may create unfamiliar composition-process combinations, so the magnitudes should not be interpreted as experimentally measured property changes.')
p('The composition-distance audit also found higher errors in less-represented composition regions. For balanced selection, far-bin MAE is 5.24 and 5.62 pp across the two partitions, compared with 3.72 and 3.40 pp in the near bins. These bins are descriptive and are not calibrated confidence categories.')

page('Discussion and conclusions')
p('The main improvement is a reduction in absolute error for high-elongation observations, rather than a large increase in R². Training weights shift the fitted response toward the priority region. The balanced objective retains better overall squared-error behavior than the tail-only objective, while improving overall MAE in the two tested partitions.')
p('The final full-data selection chooses the same estimator for balanced and tail objectives: engineered ExtraTrees with 500 trees, minimum leaf size 2 and threefold training weight for rows with EL>24%. It is fitted on all 433 eligible records after selection within three composition-grouped folds. A new input does not require its true elongation. The higher-R² comparator blends square-root CatBoost and ExtraTrees with weights 0.25 and 0.75. ExtraTrees and CatBoost follow their established algorithm families [2,3].')
p('Full-data model selection scores are not independent performance estimates. Nested validation evaluates a selection procedure, not a guarantee for a single final model. The stricter reference stress test and the retrospective literature pilot show that broader generalization remains weak. Neither final artifact should be described as externally validated.')
doc.add_heading('Data limitations',level=2)
for s in ['Original HT units, two questionable compositions and omitted processing fields remain unverified. Missing HT values do not establish absence of treatment.','Reference identities are incomplete. Shared-study effects across different compositions cannot be fully controlled for the merged dataset.','Repeated available inputs have differing measured properties. This supports investigation of missing conditions and measurement variability, not automatic deletion of those observations.','No complete test set from an independently sourced and previously unseen study has been established. The three-record pilot is insufficient for that claim.']:p(s,'List Bullet')
doc.add_heading('Final model decision',level=2)
p('Retain the weighted ExtraTrees artifact as the lower-high-elongation-error research candidate and preserve the ensemble as the higher-R² comparator. Source repair and genuinely independent validation are required before selecting a general-purpose model. Further parameter searches on the same records cannot substitute for that evidence.')
doc.add_heading('Conclusion',level=2)
p('A reproducible elongation modeling workflow has been established, with explicit composition grouping, nested selection, error-focused objectives, stricter source-label testing and held-out interpretation. The results support a useful error trade-off within the compiled dataset. They also document the remaining source and transfer limitations without changing uncertain values or presenting exploratory scores as independent accuracy.')

page('Reproducibility and completion status')
p('The project package preserves the original master workbook, earlier experiments and both fitted model options. Version-pinned dependencies and executable notebooks accompany the final audit outputs. The latest notebook is 08_Final_Research_Analysis.ipynb. Run from the extracted project root:')
for command in ['python finalize_research.py','python predict_tail.py new_inputs.xlsx predictions.csv','python predict_elongation.py new_inputs.xlsx predictions.csv']:p(command)
table(['Output','Contents'],[['Source audit CSVs','All 435 rows, 433 eligible rows, quarantine records and recovery status'],['Purged reference outputs','Fold memberships, predictions, metrics and purged counts'],['Literature pilot outputs','Source table locations, missing input, frozen model hashes and errors'],['Heldout block outputs','Raw permutations, fold means and summary figure'],['Model artifacts','Higher-R² ensemble and error-focused weighted ExtraTrees'],['Notebooks 05 to 08','Successive validation, error-focused study and final analysis']],[2.2,4.4])
table(['Task','Final status'],[['Data audit and quarantine','Complete'],['Nested and repeated grouped analysis','Complete'],['Reference-label stress test','Complete with source-mapping limitations'],['Held-out feature interpretation','Complete'],['Retrospective three-record pilot','Complete with unknown HT temperature'],['Verified source corrections','Pending original source evidence'],['Missing processing recovery','Pending original input files'],['Independent external validation','Not established']],[3.3,3.3])
p('The remaining source inputs are wha-1.xlsx, Book 4(Sheet1).csv, original unit annotations and a complete reference mapping. Field-level evidence is required for corrections. Once verified edits are available, the existing frozen protocols can be rerun; this report does not claim those edits or tests have already occurred.')
page('References')
for ref in ['[1] Fu H, Cai Q, Han Y, Li Z, Wu T, Ma Y, Liu W. Unlocking strength-ductility synergy in tungsten heavy alloys through interpretable machine learning. Materials and Design. 2026;262:115545. doi:10.1016/j.matdes.2026.115545. Data locators: Table 2, PDF page 7; Table 4 and Section 4.2, page 11.','[2] Geurts P, Ernst D, Wehenkel L. Extremely randomized trees. Machine Learning. 2006;63:3-42. doi:10.1007/s10994-006-6226-1.','[3] Prokhorenkova L, Gusev G, Vorobev A, Dorogush AV, Gulin A. CatBoost unbiased boosting with categorical features. Advances in Neural Information Processing Systems. 2018. https://proceedings.neurips.cc/paper/2018/hash/14491b756b3a51daac41c24863285549-Abstract.html','[4] Scikit-learn developers. GroupKFold documentation. https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupKFold.html. Accessed 22 October 2026.']:p(ref)
doc.core_properties.title='Prediction of Elongation in Tungsten Heavy Alloys';doc.core_properties.subject='Composition grouped model validation and source audit';doc.core_properties.author=''
for root in [doc.element,doc.styles.element]:
    for border in root.xpath('.//w:pBdr'):border.getparent().remove(border)
doc.save(O/'WHA_Elongation_Final_Report.docx')
print('Created',O/'WHA_Elongation_Final_Report.docx')
