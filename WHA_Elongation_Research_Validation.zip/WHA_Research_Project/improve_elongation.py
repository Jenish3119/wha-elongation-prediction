"""Frozen follow-up experiment: all selection uses inner composition-grouped CV."""
from pathlib import Path
import json, hashlib, warnings, sys
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.impute import SimpleImputer
from sklearn.ensemble import ExtraTreesRegressor, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from catboost import CatBoostRegressor
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
REPEAT='--repeat' in sys.argv
OUT=ROOT/'WHA_Improvement'
if REPEAT:OUT=OUT/'robustness'
OUT.mkdir(exist_ok=True,parents=True)
CACHE=OUT/'cache';CACHE.mkdir(exist_ok=True)
df=pd.read_excel(ROOT/'inputs/Master_WHA_Dataset_Cleaned.xlsx')
df.insert(0,'Excel row',np.arange(len(df))+2)
comp=[f'{e} (%)' for e in ['W','Ni','Fe','Co','Mo','Re','Cu','Mn','Cr','Ta','Hf','La']]
features=comp+['Sintering Temp (°C)','Sintering Time (hr)','Deformation Before HT (%)','HT Temp Standardized','HT Time (hr)','Post Deformation (%)']
d=df.loc[df[comp].sum(axis=1).between(98,102)].reset_index(drop=True)
groups=pd.factorize(d[comp].round(4).apply(tuple,axis=1))[0]
y=d['Elongation (%)'].to_numpy(float)
def engineering(d):
    e=d[features].copy()
    e['non_W_total']=d[comp].sum(axis=1)-d['W (%)']
    e['Ni_Fe_Co_total']=d[['Ni (%)','Fe (%)','Co (%)']].sum(axis=1)
    e['Ni_Fe_ratio']=d['Ni (%)']/d['Fe (%)'].replace(0,np.nan)
    e['Fe_absent']=(d['Fe (%)']==0).astype(int)
    e['Ni_fraction_NiFeCo']=d['Ni (%)']/e['Ni_Fe_Co_total'].replace(0,np.nan)
    e['Co_fraction_NiFeCo']=d['Co (%)']/e['Ni_Fe_Co_total'].replace(0,np.nan)
    e['Mo_Re_Ta_total']=d[['Mo (%)','Re (%)','Ta (%)']].sum(axis=1)
    pre=d['Deformation Before HT (%)'];post=d['Post Deformation (%)']
    e['sequential_reduction_proxy']=100*(1-(1-pre/100)*(1-post/100))
    e['pre_post_interaction']=pre*post/100
    e['reduction_binder_interaction']=e['sequential_reduction_proxy']*e['Ni_Fe_Co_total']/100
    e['log_sintering_time']=np.log1p(d['Sintering Time (hr)'])
    e['log_HT_time']=np.log1p(d['HT Time (hr)'])
    return e
eng=engineering(d)
variants={'base':d[features].to_numpy(float),'engineered':eng.to_numpy(float),'no_HT_temperature':eng.drop(columns='HT Temp Standardized').to_numpy(float)}
# Candidate definitions are fixed before any new outer results are calculated.
specs={
 'raw':dict(kind='cat',variant='base',depth=6,it=500,lr=.05,l2=3,target='raw',native=False),
 'sqrt':dict(kind='cat',variant='base',depth=6,it=500,lr=.05,l2=3,target='sqrt',native=False),
 'weighted':dict(kind='cat',variant='base',depth=6,it=500,lr=.05,l2=3,target='raw',native=False,weighted=True),
 'extra':dict(kind='extra',variant='base',leaf=2,trees=300),
 'eng_cat4':dict(kind='cat',variant='engineered',depth=4,it=800,lr=.03,l2=10,target='raw',native=True),
 'eng_cat6':dict(kind='cat',variant='engineered',depth=6,it=800,lr=.03,l2=10,target='raw',native=True),
 'eng_sqrt4':dict(kind='cat',variant='engineered',depth=4,it=800,lr=.03,l2=10,target='sqrt',native=True),
 'eng_sqrt6':dict(kind='cat',variant='engineered',depth=6,it=800,lr=.03,l2=10,target='sqrt',native=True),
 'eng_extra':dict(kind='extra',variant='engineered',leaf=2,trees=500),
 'eng_RF':dict(kind='rf',variant='engineered',leaf=2,trees=500),
 'eng_no_HT':dict(kind='cat',variant='no_HT_temperature',depth=4,it=800,lr=.03,l2=10,target='raw',native=True),
 'eng_svr':dict(kind='svr',variant='engineered',C=10,gamma=.03),
}
blends={f'sqrt_extra_{w}':{'sqrt':w,'extra':1-w} for w in [.25,.5,.75]}
for name,left,right in [('eng_blend','eng_cat4','eng_extra'),('eng_sqrt_blend','eng_sqrt4','eng_extra'),('eng6_blend','eng_cat6','eng_RF')]:
    for w in [.25,.5,.75]:blends[f'{name}_{w}']={left:w,right:1-w}
old_names=['raw','sqrt','weighted','extra']+[f'sqrt_extra_{w}' for w in [.25,.5,.75]]
plan={'protocol':'5 outer, 3 inner GroupKFold; mean inner R2 selects. No outer tuning. Primary uses deterministic original groups/folds. Robustness repeat shuffles both outer/inner composition groups with seed 2026.','is_robustness_repeat':REPEAT,'specs':specs,'blends':blends,'n_rows':len(d),'n_groups':len(np.unique(groups)),'features':{k:list(eng.columns) if k=='engineered' else (features if k=='base' else list(eng.drop(columns='HT Temp Standardized').columns)) for k in variants},'data_sha256':hashlib.sha256((ROOT/'inputs/Master_WHA_Dataset_Cleaned.xlsx').read_bytes()).hexdigest()}
(OUT/'experiment_plan.json').write_text(json.dumps(plan,indent=2))
CACHE_FINGERPRINT=hashlib.sha256(json.dumps(plan,sort_keys=True).encode()+b''.join(x.tobytes() for x in variants.values())+y.tobytes()).hexdigest()[:16]
def prediction(name,tr,te,tag):
    split_hash=hashlib.sha256(np.asarray(tr).tobytes()+np.asarray(te).tobytes()).hexdigest()[:12]
    path=CACHE/f'{CACHE_FINGERPRINT}_{split_hash}_{tag}_{name}.npy'
    if path.exists():return np.load(path)
    s=specs[name];x=variants[s['variant']]
    a=x[tr];b=x[te]
    if not s.get('native',False):
        imp=SimpleImputer(strategy='median',add_indicator=True);a=imp.fit_transform(a);b=imp.transform(b)
    target=np.sqrt(y[tr]) if s.get('target')=='sqrt' else y[tr]
    if s['kind']=='cat':
        model=CatBoostRegressor(iterations=s['it'],depth=s['depth'],learning_rate=s['lr'],l2_leaf_reg=s['l2'],random_seed=42,verbose=False,thread_count=2,allow_writing_files=False)
    elif s['kind'] in ['extra','rf']:
        cls=ExtraTreesRegressor if s['kind']=='extra' else RandomForestRegressor
        model=cls(n_estimators=s['trees'],min_samples_leaf=s['leaf'],random_state=42,n_jobs=2)
    else:
        sc=StandardScaler();a=sc.fit_transform(a);b=sc.transform(b);model=SVR(C=s['C'],gamma=s['gamma'],epsilon=.5)
    kw={'sample_weight':np.where(y[tr]>24,2.,1.)} if s.get('weighted') else {}
    model.fit(a,target,**kw);p=model.predict(b)
    if s.get('target')=='sqrt':p=np.maximum(p,0)**2
    assert np.isfinite(p).all()
    np.save(path,p);return p
def mix(pred):
    allpred=dict(pred)
    for name,weights in blends.items():allpred[name]=sum(w*pred[k] for k,w in weights.items())
    return allpred
def metrics(t,p):
    h=t>24
    return {'R2':float(r2_score(t,p)),'MAE_pp':float(mean_absolute_error(t,p)),'RMSE_pp':float(np.sqrt(mean_squared_error(t,p))),'high_EL_n':int(h.sum()),'high_EL_MAE_pp':float(mean_absolute_error(t[h],p[h])) if h.any() else np.nan}
outer=GroupKFold(5,shuffle=True,random_state=2026) if REPEAT else GroupKFold(5)
oo={k:np.full(len(d),np.nan) for k in ['fixed_baseline','previous_selection','expanded_selection']};foldid=np.zeros(len(d),int)
foldrows=[];selection=[];outer_candidates=[]
for f,(tr,te) in enumerate(outer.split(variants['base'],y,groups),1):
    print('Starting outer fold',f,flush=True)
    assert set(groups[tr]).isdisjoint(groups[te])
    ip={k:np.full(len(tr),np.nan) for k in specs};valid=[]
    inner=GroupKFold(3,shuffle=True,random_state=2026) if REPEAT else GroupKFold(3)
    for j,(a,b) in enumerate(inner.split(tr,y[tr],groups[tr]),1):
        assert set(groups[tr[a]]).isdisjoint(groups[tr[b]])
        for name in specs:ip[name][b]=prediction(name,tr[a],tr[b],f'outer{f}_inner{j}')
        valid.append(b)
    candidates=mix(ip)
    scores={k:float(np.mean([r2_score(y[tr][b],p[b]) for b in valid])) for k,p in candidates.items()}
    old=max(old_names,key=lambda k:scores[k]);win=max(scores,key=scores.get)
    selection.extend({'outer_fold':f,'candidate':k,'mean_inner_R2':v,'selected_previous':k==old,'selected_expanded':k==win} for k,v in scores.items())
    needed={'raw'}
    for k in [old,win]:needed.update(blends[k] if k in blends else [k])
    op={k:prediction(k,tr,te,f'outer{f}_test') for k in needed}
    for k in [old,win]:
        if k in blends:op[k]=sum(w*op[n] for n,w in blends[k].items())
    for label,key in [('fixed_baseline','raw'),('previous_selection',old),('expanded_selection',win)]:
        oo[label][te]=op[key]
        foldrows.append({'outer_fold':f,'procedure':label,'candidate':key,'test_n':len(te),**metrics(y[te],op[key])})
    foldid[te]=f
    print('Fold',f,'previous:',old,'expanded:',win,'R2:',r2_score(y[te],op[win]),flush=True)
fm=pd.DataFrame(foldrows);fm.to_csv(OUT/'outer_fold_metrics.csv',index=False)
pd.DataFrame(selection).to_csv(OUT/'inner_candidate_scores.csv',index=False)
summary=pd.DataFrame([{'procedure':k,**metrics(y,p),'mean_fold_R2':fm.loc[fm.procedure==k,'R2'].mean(),'sd_fold_R2':fm.loc[fm.procedure==k,'R2'].std()} for k,p in oo.items()])
summary.to_csv(OUT/'comparison.csv',index=False)
preds=d[['Excel row','Data Source','Original Composition','Reference','Elongation (%)']].copy();preds['composition_group']=groups;preds['outer_fold']=foldid
for k,p in oo.items():preds[k+'_prediction']=p;preds[k+'_absolute_error']=abs(y-p)
preds.to_csv(OUT/'OOF_predictions.csv',index=False)
preds.sort_values('expanded_selection_absolute_error',ascending=False).head(30).to_csv(OUT/'largest_errors.csv',index=False)
# Verify the old procedure is exactly reproduced, not just compared with a different split.
prior=pd.read_csv(ROOT/'WHA_Research_Validation/out_of_fold_predictions.csv')
assert np.array_equal(prior['Excel row'],preds['Excel row'])
if not REPEAT:
    assert np.array_equal(prior['outer_fold'],foldid)
    assert np.allclose(prior['selected_OOF_prediction'],oo['previous_selection'],atol=1e-9)
    assert np.allclose(prior['baseline_OOF_prediction'],oo['fixed_baseline'],atol=1e-9)
# Bootstrap paired differences by composition, conditional on already-computed OOF predictions.
rng=np.random.default_rng(42);ug=np.unique(groups);boot=[]
for _ in range(2000):
    ix=np.concatenate([np.flatnonzero(groups==g) for g in rng.choice(ug,len(ug),replace=True)])
    boot.append(r2_score(y[ix],oo['expanded_selection'][ix])-r2_score(y[ix],oo['previous_selection'][ix]))
ci=np.quantile(boot,[.025,.975]);(OUT/'uncertainty.json').write_text(json.dumps({'expanded_minus_previous_pooled_R2_95pct_interval':ci.tolist(),'group_resamples':2000,'limitation':'Conditional OOF bootstrap. Reused previously explored data, no external-test claim.'},indent=2))
# Input-identical records: differing labels demonstrate missing predictors/measurement differences.
key=pd.util.hash_pandas_object(d[features],index=False)
dupes=d.assign(input_group=key).groupby('input_group').agg(n=('Elongation (%)','size'),EL_min=('Elongation (%)','min'),EL_max=('Elongation (%)','max'),EL_mean=('Elongation (%)','mean'))
dupes['range_pp']=dupes.EL_max-dupes.EL_min
dupes=dupes[dupes.n>1].sort_values('range_pp',ascending=False)
dupes.to_csv(OUT/'identical_input_target_spread.csv')
duplicate_rows=d.assign(input_group=key);duplicate_rows[duplicate_rows.input_group.isin(dupes.index)].to_csv(OUT/'identical_input_records.csv',index=False)
# Error breakdowns are diagnostic only, never used for choosing candidates.
parts=[]
for title,mask in [('EL <= 10%',y<=10),('10% < EL <= 24%',(y>10)&(y<=24)),('EL > 24%',y>24),('Dataset 1',(d['Data Source']=='Dataset 1').to_numpy()),('Dataset 2',(d['Data Source']=='Dataset 2').to_numpy())]:
    for k,p in oo.items():parts.append({'subset':title,'procedure':k,'n':int(mask.sum()),**metrics(y[mask],p[mask])})
pd.DataFrame(parts).to_csv(OUT/'error_breakdown.csv',index=False)
fig,axes=plt.subplots(1,2,figsize=(11,4.7))
for ax,k in zip(axes,['previous_selection','expanded_selection']):
    ax.scatter(y,oo[k],s=18,alpha=.6,color='#227c9d');ax.plot([0,40],[0,40],'k--',lw=1);ax.set(xlabel='Observed elongation (%)',ylabel='OOF prediction (%)',title=k.replace('_',' ').title(),xlim=(0,40),ylim=(0,40))
fig.tight_layout();fig.savefig(OUT/'prediction_comparison.png',dpi=170);plt.close(fig)
print(summary.to_string(index=False),flush=True);print('Paired interval:',ci,flush=True)
