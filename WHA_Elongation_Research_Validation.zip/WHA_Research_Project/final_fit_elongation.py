from pathlib import Path
import json,joblib,numpy as np,pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score
from elongation_predictor import COMP,FEATURES,fit_component,component_predict,predict,engineered
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'WHA_Improvement'
plan=json.loads((OUT/'experiment_plan.json').read_text());specs=plan['specs'];blends=plan['blends']
df=pd.read_excel(ROOT/'inputs/Master_WHA_Dataset_Cleaned.xlsx');d=df[df[COMP].sum(axis=1).between(98,102)].reset_index(drop=True);y=d['Elongation (%)'].to_numpy(float)
groups=pd.factorize(d[COMP].round(4).apply(tuple,axis=1))[0]
ip={k:np.full(len(d),np.nan) for k in specs};folds=[]
for fold,(tr,te) in enumerate(GroupKFold(3).split(d,y,groups),1):
    print('Final model selection fold',fold,flush=True)
    assert set(groups[tr]).isdisjoint(groups[te])
    for k,s in specs.items():
        component=fit_component(d.iloc[tr],y[tr],s);ip[k][te]=component_predict(component,d.iloc[te])
    folds.append(te)
for k,ws in blends.items():ip[k]=sum(w*ip[n] for n,w in ws.items())
scores={k:float(np.mean([r2_score(y[ix],p[ix]) for ix in folds])) for k,p in ip.items()}
winner=max(scores,key=scores.get);weights=blends.get(winner,{winner:1.})
pd.DataFrame([{'candidate':k,'mean_selection_R2':v,'selected':k==winner} for k,v in scores.items()]).to_csv(OUT/'final_fit_selection.csv',index=False)
bundle={'candidate':winner,'weights':weights,'features':FEATURES,'training_rows':len(d),'training_composition_groups':len(np.unique(groups)),'target':'Elongation (%)','components':{k:fit_component(d,y,specs[k]) for k in weights},'feature_ranges':{c:[float(d[c].min()),float(d[c].max())] for c in FEATURES},'validation_note':'Use nested validation procedure results. Full-data model selection scores are not independent performance estimates. Source temperature units remain unresolved.'}
joblib.dump(bundle,OUT/'Elongation_Model.joblib',compress=3)
loaded=joblib.load(OUT/'Elongation_Model.joblib');p1=predict(bundle,d.iloc[:10]);p2=predict(loaded,d.iloc[:10]);assert np.allclose(p1.prediction_EL_percent,p2.prediction_EL_percent)
invalid=d.iloc[:1].copy();invalid['W (%)']=0;assert predict(loaded,invalid).prediction_EL_percent.isna().all()
meta={k:v for k,v in bundle.items() if k!='components'};(OUT/'model_metadata.json').write_text(json.dumps(meta,indent=2))
print('Full-data selected candidate:',winner,flush=True)
