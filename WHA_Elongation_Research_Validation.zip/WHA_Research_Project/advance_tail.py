"""Predeclared constrained high-elongation selection and applicability audit."""
from pathlib import Path
import sys,json,hashlib,copy
import numpy as np,pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score,mean_absolute_error,mean_squared_error
from scipy.spatial.distance import cdist
from elongation_predictor import COMP,FEATURES,fit_component,component_predict

ROOT=Path(__file__).resolve().parent;REPEAT='--repeat' in sys.argv
OUT=ROOT/'WHA_Tail_Study'
if REPEAT:OUT=OUT/'robustness'
OUT.mkdir(parents=True,exist_ok=True);CACHE=OUT/'cache';CACHE.mkdir(exist_ok=True)
PRIOR=ROOT/'WHA_Improvement'
if REPEAT:PRIOR=PRIOR/'robustness'
plan=json.loads((PRIOR/'experiment_plan.json').read_text())
raw=(ROOT/'inputs/Master_WHA_Dataset_Cleaned.xlsx').read_bytes();data_hash=hashlib.sha256(raw).hexdigest()
assert data_hash==plan['data_sha256']
df=pd.read_excel(ROOT/'inputs/Master_WHA_Dataset_Cleaned.xlsx');df.insert(0,'Excel row',np.arange(len(df))+2)
d=df[df[COMP].sum(axis=1).between(98,102)].reset_index(drop=True);y=d['Elongation (%)'].to_numpy(float)
groups=pd.factorize(d[COMP].round(4).apply(tuple,axis=1))[0]
specs=copy.deepcopy(plan['specs']);old_names=list(specs);blends=copy.deepcopy(plan['blends'])
for base in ['eng_cat4','eng_extra','eng_RF']:
    for suffix,extra in [('high2',{'high_weight':2.}),('group',{'group_balance':True}),('group_high2',{'group_balance':True,'high_weight':2.})]:
        specs[base+'_'+suffix]={**copy.deepcopy(specs[base]),**extra}
specs['eng_cat4_high3']={**copy.deepcopy(specs['eng_cat4']),'high_weight':3.}
specs['eng_extra_high3']={**copy.deepcopy(specs['eng_extra']),'high_weight':3.}
study={'objective':'Reduce held-out inner high-EL (>24%) MAE, constrained by mean inner R2 >= R2-selected reference -0.02 and pooled inner overall MAE <= 1.03 times reference. A balanced alternative minimizes equal-bin MAE (<=10,10-24,>24) under the same guards. Infeasible selections fall back to reference. Outer results never enter selection.','is_repeat':REPEAT,'specs':specs,'blends':blends,'data_sha256':data_hash,'source_protocol':plan['protocol'],'reuse':'Prior inner prediction arrays reused only for identical input hash, split definitions, model specifications and feature functions; older cache names correspond to this exact previous experiment.'}
(OUT/'study_plan.json').write_text(json.dumps(study,indent=2))
fingerprint=hashlib.sha256(json.dumps(study,sort_keys=True).encode()).hexdigest()[:16]
def prediction(name,tr,te,tag):
    oldpath=PRIOR/'cache'/f'{tag}_{name}.npy'
    if name in old_names and oldpath.exists():
        p=np.load(oldpath);assert p.shape==(len(te),);return p
    key=hashlib.sha256(np.asarray(tr).tobytes()+np.asarray(te).tobytes()).hexdigest()[:12]
    path=CACHE/f'{fingerprint}_{key}_{tag}_{name}.npy'
    if path.exists():return np.load(path)
    c=fit_component(d.iloc[tr],y[tr],specs[name]);p=component_predict(c,d.iloc[te]);assert np.isfinite(p).all();np.save(path,p);return p
def mix(p):
    z=dict(p)
    for k,ws in blends.items():z[k]=sum(w*p[n] for n,w in ws.items())
    return z
def metric(t,p):
    h=t>24;bins=[t<=10,(t>10)&(t<=24),t>24]
    return {'R2':float(r2_score(t,p)),'MAE_pp':float(mean_absolute_error(t,p)),'RMSE_pp':float(np.sqrt(mean_squared_error(t,p))),'high_EL_n':int(h.sum()),'high_EL_MAE_pp':float(mean_absolute_error(t[h],p[h])) if h.any() else np.nan,'equal_bin_MAE_pp':float(np.mean([mean_absolute_error(t[m],p[m]) for m in bins if m.any()]))}
def choose(yy,pred,indices):
    stats={k:{**metric(yy,p),'mean_inner_R2':float(np.mean([r2_score(yy[ix],p[ix]) for ix in indices]))} for k,p in pred.items()}
    original=list(plan['specs'])+list(plan['blends'])
    ref=max(original,key=lambda k:stats[k]['mean_inner_R2'])
    eligible=[k for k,s in stats.items() if s['mean_inner_R2']>=stats[ref]['mean_inner_R2']-.02 and s['MAE_pp']<=stats[ref]['MAE_pp']*1.03]
    assert ref in eligible
    tail=min(eligible,key=lambda k:stats[k]['high_EL_MAE_pp']);balanced=min(eligible,key=lambda k:stats[k]['equal_bin_MAE_pp'])
    return ref,tail,balanced,stats,eligible
outer=GroupKFold(5,shuffle=True,random_state=2026) if REPEAT else GroupKFold(5)
oof={k:np.full(len(d),np.nan) for k in ['reference','tail_focus','balanced_focus']}
foldrows=[];selection=[];fid=np.zeros(len(d),int);nearest=np.zeros(len(d))
for f,(tr,te) in enumerate(outer.split(d,y,groups),1):
    print('Outer fold',f,flush=True);assert set(groups[tr]).isdisjoint(groups[te])
    inner=GroupKFold(3,shuffle=True,random_state=2026) if REPEAT else GroupKFold(3)
    ip={k:np.full(len(tr),np.nan) for k in specs};ixs=[]
    for j,(a,b) in enumerate(inner.split(tr,y[tr],groups[tr]),1):
        assert set(groups[tr[a]]).isdisjoint(groups[tr[b]])
        for k in specs:ip[k][b]=prediction(k,tr[a],tr[b],f'outer{f}_inner{j}')
        ixs.append(b)
    ref,tail,bal,stats,eligible=choose(y[tr],mix(ip),ixs)
    selection.extend({'outer_fold':f,'candidate':k,'eligible':k in eligible,'chosen_reference':k==ref,'chosen_tail':k==tail,'chosen_balanced':k==bal,**s} for k,s in stats.items())
    needed=set()
    for k in [ref,tail,bal]:needed.update(blends[k] if k in blends else [k])
    op={k:prediction(k,tr,te,f'outer{f}_test') for k in needed}
    for k in [ref,tail,bal]:
        if k in blends:op[k]=sum(w*op[n] for n,w in blends[k].items())
    for label,k in [('reference',ref),('tail_focus',tail),('balanced_focus',bal)]:
        oof[label][te]=op[k];foldrows.append({'outer_fold':f,'procedure':label,'candidate':k,'test_n':len(te),**metric(y[te],op[k])})
    nearest[te]=cdist(d.iloc[te][COMP].to_numpy(),d.iloc[tr][COMP].to_numpy()).min(axis=1)
    fid[te]=f
    print('Selected',ref,tail,bal,'tail held-out MAE',metric(y[te],op[tail])['high_EL_MAE_pp'],flush=True)
fm=pd.DataFrame(foldrows);fm.to_csv(OUT/'outer_fold_metrics.csv',index=False)
pd.DataFrame(selection).to_csv(OUT/'inner_selection.csv',index=False)
summary=pd.DataFrame([{'procedure':k,**metric(y,p),'mean_fold_R2':fm.loc[fm.procedure==k,'R2'].mean()} for k,p in oof.items()]);summary.to_csv(OUT/'comparison.csv',index=False)
pr=pd.read_csv(PRIOR/'OOF_predictions.csv');assert np.array_equal(pr['Excel row'],d['Excel row']);assert np.array_equal(pr['outer_fold'],fid);assert np.allclose(pr['expanded_selection_prediction'],oof['reference'],atol=1e-9)
preds=d[['Excel row','Data Source','Original Composition','Reference','Elongation (%)']].copy();preds['composition_group']=groups;preds['outer_fold']=fid;preds['nearest_training_composition_L2_pp']=nearest
for k,p in oof.items():preds[k+'_prediction']=p;preds[k+'_absolute_error']=abs(y-p)
preds.to_csv(OUT/'OOF_predictions.csv',index=False)
preds.loc[y>24].sort_values('tail_focus_absolute_error',ascending=False).to_csv(OUT/'high_EL_error_review.csv',index=False)
preds['composition_distance_bin']=pd.qcut(nearest,3,labels=['near','middle','far'],duplicates='drop')
distance=[]
for label,g in preds.groupby('composition_distance_bin',observed=True):
    for k in oof:distance.append({'distance_bin':label,'procedure':k,'n':len(g),'distance_min_pp':g.nearest_training_composition_L2_pp.min(),'distance_max_pp':g.nearest_training_composition_L2_pp.max(),'MAE_pp':g[k+'_absolute_error'].mean()})
pd.DataFrame(distance).to_csv(OUT/'composition_distance_diagnostics.csv',index=False)
rng=np.random.default_rng(42);ug=np.unique(groups);boot={k:[] for k in ['tail_focus','balanced_focus']}
for _ in range(2000):
    ix=np.concatenate([np.flatnonzero(groups==g) for g in rng.choice(ug,len(ug),replace=True)]);h=y[ix]>24
    for k in boot:boot[k].append(mean_absolute_error(y[ix][h],oof[k][ix][h])-mean_absolute_error(y[ix][h],oof['reference'][ix][h]))
cis={k:np.quantile(v,[.025,.975]).tolist() for k,v in boot.items()}
(OUT/'high_EL_uncertainty.json').write_text(json.dumps({'high_EL_MAE_difference_vs_reference_95pct_group_bootstrap_interval':cis,'note':'Negative means lower high-EL MAE. Conditional on OOF predictions; same previously explored dataset, not an independent external test.'},indent=2))
print(summary.to_string(index=False),flush=True);print('High EL MAE difference intervals',cis,flush=True)
