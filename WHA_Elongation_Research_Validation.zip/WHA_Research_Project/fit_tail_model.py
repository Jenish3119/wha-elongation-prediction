from pathlib import Path
import json,joblib,numpy as np,pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score,mean_absolute_error
from elongation_predictor import COMP,FEATURES,fit_component,component_predict,predict
R=Path(__file__).resolve().parent;O=R/'WHA_Tail_Study'
plan=json.loads((O/'study_plan.json').read_text());specs=plan['specs'];blends=plan['blends']
old=json.loads((R/'WHA_Improvement/experiment_plan.json').read_text());old_names=list(old['specs'])+list(old['blends'])
df=pd.read_excel(R/'inputs/Master_WHA_Dataset_Cleaned.xlsx');d=df[df[COMP].sum(axis=1).between(98,102)].reset_index(drop=True);y=d['Elongation (%)'].to_numpy(float)
groups=pd.factorize(d[COMP].round(4).apply(tuple,axis=1))[0]
p={k:np.full(len(d),np.nan) for k in specs};ixs=[]
for f,(tr,te) in enumerate(GroupKFold(3).split(d,y,groups),1):
    print('Full-data tail selection fold',f,flush=True)
    assert set(groups[tr]).isdisjoint(groups[te])
    for k,s in specs.items():
        c=fit_component(d.iloc[tr],y[tr],s);p[k][te]=component_predict(c,d.iloc[te])
    ixs.append(te)
for k,ws in blends.items():p[k]=sum(w*p[n] for n,w in ws.items())
stats={}
for k,pr in p.items():
    bins=[y<=10,(y>10)&(y<=24),y>24]
    stats[k]={'mean_inner_R2':float(np.mean([r2_score(y[ix],pr[ix]) for ix in ixs])),'MAE_pp':float(mean_absolute_error(y,pr)),'high_EL_MAE_pp':float(mean_absolute_error(y[y>24],pr[y>24])),'equal_bin_MAE_pp':float(np.mean([mean_absolute_error(y[m],pr[m]) for m in bins]))}
ref=max(old_names,key=lambda k:stats[k]['mean_inner_R2'])
eligible=[k for k,s in stats.items() if s['mean_inner_R2']>=stats[ref]['mean_inner_R2']-.02 and s['MAE_pp']<=1.03*stats[ref]['MAE_pp']]
tail=min(eligible,key=lambda k:stats[k]['high_EL_MAE_pp']);balanced=min(eligible,key=lambda k:stats[k]['equal_bin_MAE_pp'])
pd.DataFrame([{'candidate':k,'eligible':k in eligible,'selected_tail':k==tail,'selected_balanced':k==balanced,**s} for k,s in stats.items()]).to_csv(O/'full_data_selection.csv',index=False)
ws=blends.get(tail,{tail:1.})
bundle={'candidate':tail,'weights':ws,'features':FEATURES,'training_rows':len(d),'training_composition_groups':len(np.unique(groups)),'target':'Elongation (%)','components':{k:fit_component(d,y,specs[k]) for k in ws},'feature_ranges':{c:[float(d[c].min()),float(d[c].max())] for c in FEATURES},'validation_note':'Alternative high-elongation-focused objective, not an established overall replacement. Refer to nested tail study. Source temperatures remain unresolved.'}
bundle['full_data_balanced_candidate']=balanced
bundle['selected_for']=['tail_focus','balanced_focus'] if tail==balanced else ['tail_focus']
joblib.dump(bundle,O/'High_Elongation_Model.joblib',compress=3)
loaded=joblib.load(O/'High_Elongation_Model.joblib');assert np.allclose(predict(loaded,d.iloc[:10]).prediction_EL_percent,predict(bundle,d.iloc[:10]).prediction_EL_percent)
(O/'tail_model_metadata.json').write_text(json.dumps({k:v for k,v in bundle.items() if k!='components'},indent=2))
print('Reference:',ref,'Tail:',tail,'Balanced:',balanced,flush=True)
